<?php
 /**
  * Attendance caller, List of all Employees in a table to be printed
  *
  * @package EAS
  */
 require './@config/config.php';
 require './@config/db.config.php';
 require './libs/class.error.php';
 require './libs/class.config.php';
 
 if(isset($_POST["attendance"])) {
 	$empid = $_POST["empid"];
	$mstart = $_POST["m_start"];
	$mstop = $_POST["m_stop"];
	$afstart = $_POST["af_start"];
	$afstop = $_POST["af_stop"];
	$presence = $_POST["presence"];
	$shift = $_GET["shift"];
	
	//timestamps
	$now = time();
	$day = date('d', time());
	$month = date('M', time());
	$year = date('Y', time());
	
	if($shift == "morning" && $mstart != null && $mstop != null && $presence == "on")
	{
		$val = $sql->query("SELECT * FROM attendance WHERE EMP_ID='{$empid}' AND Day='{$day}' AND Month='{$month}' AND Year='{$year}'");
		if(mysqli_num_rows($val)) {
			$m = $mstart."-".$mstop;
			$exec = $sql->query("UPDATE attendance SET Attendance='{$m}' WHERE EMP_ID='{$empid}' AND Day='{$day}' AND Month='{$month}' AND Year='{$year}' ");
			if($exec) {
				EAS_ERRORS::JSAlert("Attendance updated!");
			} else {
				EAS_ERRORS::Warning(mysqli_error($sql));
			}
		} else {
			$m = $mstart."-".$mstop;
			$exec = $sql->query("INSERT INTO attendance (EMP_ID, Day, Month, Year, Attendance, LastUpdate) VALUES ('$empid', '$day', '$month', '$year', '$m', '$now')");
			if($exec) {
				EAS_ERRORS::JSAlert("Attendance saved!");
			} else {
				EAS_ERRORS::JSAlert(mysqli_error($sql));
			}
		}
	} elseif($shift == "morning" && $presence != "on") {
		/**
		 * absent (morning shift)
		 */
		$val = $sql->query("SELECT * FROM attendance WHERE EMP_ID='{$empid}' AND Day='{$day}' AND Month='{$month}' AND Year='{$year}'");
		if(mysqli_num_rows($val)) {
			$exec = $sql->query("UPDATE attendance SET Attendance='' WHERE EMP_ID='{$empid}' AND Day='{$day}' AND Month='{$month}' AND Year='{$year}' ");
			if($exec) {
				EAS_ERRORS::JSAlert("Attendance updated! (Absent)");
			} else {
				EAS_ERRORS::Warning(mysqli_error($sql));
			}
		} else {
			$exec = $sql->query("INSERT INTO attendance (EMP_ID, Day, Month, Year, Attendance, LastUpdate) VALUES ('$empid', '$day', '$month', '$year', '', '$now')");
			if($exec) {
				EAS_ERRORS::JSAlert("Attendance saved! (Absent)");
			} else {
				EAS_ERRORS::JSAlert(mysqli_error($sql));
			}
		}
	} //ends morning shift
	
	
	
	
	
	
	
	
	
	
	/**
	 * afternoon shift
	 */
	if($shift == "afternoon" && $afstart != null && $afstop != null && $presence == "on")
	{
		$val = $sql->query("SELECT * FROM attendance WHERE EMP_ID='{$empid}' AND Day='{$day}' AND Month='{$month}' AND Year='{$year}'");
		if(mysqli_num_rows($val)) {
			
			$att = mysqli_fetch_array($val);
			$att = $att["Attendance"];
			
			$shifts = explode("&", $att);
			$morning = ltrim($shifts[0]);
			
			$att = $morning." & ".$afstart."-".$afstop;
			$exec = $sql->query("UPDATE attendance SET Attendance='{$att}' WHERE EMP_ID='{$empid}' AND Day='{$day}' AND Month='{$month}' AND Year='{$year}' ");
			if($exec) {
				EAS_ERRORS::JSAlert("Attendance updated!");
			} else {
				EAS_ERRORS::Warning(mysqli_error($sql));
			}
			
		} else {
			$att = " & ".$afstart."-".$afstop;
			$exec = $sql->query("UPDATE attendance SET Attendance='{$att}' WHERE EMP_ID='{$empid}' AND Day='{$day}' AND Month='{$month}' AND Year='{$year}' ");
			if($exec) {
				EAS_ERRORS::JSAlert("Attendance updated!");
			} else {
				EAS_ERRORS::Warning(mysqli_error($sql));
			}
		}
	} elseif($shift == "afternoon" && $presence != "on") {
		/**
		 * absent (afternoon shift)
		 */
		$val = $sql->query("SELECT * FROM attendance WHERE EMP_ID='{$empid}' AND Day='{$day}' AND Month='{$month}' AND Year='{$year}'");
		if(mysqli_num_rows($val)) {
			
			$att = mysqli_fetch_array($val);
			$att = $att["Attendance"];
			
			$shifts = explode("&", $att);
			$morning = ltrim($shifts[0]);
			
			$att = $morning;
			$exec = $sql->query("UPDATE attendance SET Attendance='{$att}' WHERE EMP_ID='{$empid}' AND Day='{$day}' AND Month='{$month}' AND Year='{$year}' ");
			if($exec) {
				EAS_ERRORS::JSAlert("Attendance updated! (Absent)");
			} else {
				EAS_ERRORS::Warning(mysqli_error($sql));
			}
			
		} else {
			$att = "";
			$exec = $sql->query("UPDATE attendance SET Attendance='{$att}' WHERE EMP_ID='{$empid}' AND Day='{$day}' AND Month='{$month}' AND Year='{$year}' ");
			if($exec) {
				EAS_ERRORS::JSAlert("Attendance updated! (Absent)");
			} else {
				EAS_ERRORS::Warning(mysqli_error($sql));
			}
		}
   } //ends afternoon shift
	
 }
 
 
 
 $shift = "OutOfTime"; //query for restarting var
 $now_ = date('ha', time());
 switch($now_) {
 	case "09am":
 	  $shift = "morning";
 	  break;
 	case "10am":
 	  $shift = "morning";
 	  break;
 	case "11am":
 	  $shift = "morning";
 	  break;
 	case "12pm":
 	  $shift = "morning";
 	  break;
 	case "01pm":
 	  $shift = "morning";
 	  break;
 	
 	case "02pm":
 	  $shift = "afternoon";
 	  break;
 	case "03pm":
 	  $shift = "afternoon";
 	  break;
 	case "04pm":
 	  $shift = "afternoon";
 	  break;
 	case "05pm":
 	  $shift = "afternoon";
 	  break;
 	case "06pm":
 	  $shift = "afternoon";
 	  break;
 }
?><!DOCTYPE html>
<html lang="en">
   <head>
      <meta charset="utf-8">
      <!--<meta name="viewport" content="initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no"> -->
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="msapplication-tap-highlight" content="no">
      <meta name="theme-color" content="#607d8b">
      <link rel="STYLESHEET" href="./res/css/materialize.min.css"/>
      <link rel="STYLESHEET" href="./res/css/font-awesome.min.css" />
      <script src="./res/js/jquery.min.js"></script>
      <script src="./res/js/materialize.min.js"></script>
      <style>
      	table.responsive-table {
            margin-left: 10px;
            margin-right: 10px;
            margin-top: 10px;
            width:97.9%;
            border-radius: 2px;
            border: 1px solid #a6a6a6;
         }
         table.responsive-table th, td {
            padding: 15px 18px;
         }
         table.responsive-table td.option {
            color: #009688;
         }
         .savebtn {
            padding: 7px 10px;
            color: white;
            border-radius: 2px;
            border: 0;
         }
         input[type=text].tpicker {
         	display: inline-block;
            width: 59px;
            border: 1px solid grey;
            padding: 6px;
            height: 13px;
            text-align: center; color: black;
            pointer-events: none;
            tab-index: -1;
         }
         .search {
         	background-image: url('./res/icons/searchicon.png');
         	background-repeat: no-repeat;
         	background-position: 12px 12px;
         }
         
         .dropdown {
         	display: inline-block;
         	position: relative;
         }
         .dropdown .drop-menu {
         	position: absolute;
         	z-index: 9999;
         	top: 59%;
         	display: none;
         	background: white;
         	left: 0; right: 0;
         	box-shadow: 0px 2px 9px 0px rgba(0,0,0,0.2);
         }
         .dropdown .drop-menu time {
         	display: block;
         	padding: 2px;
         	text-align: center;
         }
         .dropdown .drop-menu time:hover {
         	background: #009688;
         	color: white;
         }
         .dropdown .drop-menu time[disabled] {
         	color: grey;
         }
         .dropdown .drop-menu time[disabled]:hover {
         	background: white;
         }
         .dropdown:hover .drop-menu {
         	display: block;
         }
      </style>
      <script>
         $(document).ready(function() {
            $('select').material_select();
         });
      </script>
   </head>
   <body>
      <?php
   	  if($shift != "OutOfTime") {
   	?>
   	<div class="row white" style="border-bottom: 1px solid #a6a6a6; margin: 0;">
   		<div class="col s6" style="text-align: left; padding: 9px;">
   			<b>ADD ATTENDANCE</b> &nbsp; &nbsp;
   			<span class="color: grey;">|</span> &nbsp; &nbsp;
   			<b><a href="today_attendance.php" class="teal-text">PRESENT EMPLOYEES</a></b>
   		</div>
   		<div class="col s6" style="text-align: right; padding: 0px;">
   			 <form method="GET" action="">
   			  	<input type="search" placeholder="Search an employee" class="search teal-text" style="margin: 0; padding: 0px; width: 50%; padding-left: 40px;" name="query" value="<?php echo $_GET["query"]; ?>"/>
   			  	</form>
   		</div>
   	</div>
   	
   	
      <table class=" highlight bordered">
         <thead>
         <tr>
            <th data-field="id">ID</th>
            <th data-field="name">Name</th>
            <th data-field="price">Department</th>
            <?php if($shift == "morning") { echo '<th>Morning shift</th>';  }
            if($shift == "afternoon") { echo '<th>Afternoon shift</th>'; } ?>
            <th data-field="price">Present</th>
            <th>Action</th>
         </tr>
         </thead>

         <tbody>
         <?php
           if(isset($_GET["query"])) {
           	  $sq = $_GET["query"];
           	  $query = "SELECT * FROM employees WHERE FullName LIKE '%$sq%' OR Email LIKE '%$sq%' OR id LIKE '%$sq%' OR Phone LIKE '%$sq'";
           } else {
           	 $query = "SELECT * FROM employees";
           }
           $excution = $sql->query($query);
           if(mysqli_num_rows($excution)) {
           while($row = mysqli_fetch_object($excution)) {
         ?>
         <script>
         /**
          * morning shift validation
          */
         function validate_morning<?php echo $row->id; ?>() {
         	var _morning<?php echo $row->id; ?> = $("[contain=_morning<?php echo $row->id; ?>]");
         	var morning_<?php echo $row->id; ?> = $("[contain=morning_<?php echo $row->id; ?>]");
         	/**
         	 * check two values if they are same
         	 */
         	if(_morning<?php echo $row->id; ?>.val() == morning_<?php echo $row->id; ?>.val()) {
         		morning_<?php echo $row->id; ?>.val("1.00pm");
         	}
         	
         	/**
         	 * set the default values
         	 */
         	$("time#m10_<?php echo $row->id; ?>").attr("onclick", 'morning_<?php echo $row->id; ?>("10.00am")');
         	$("time#m10_<?php echo $row->id; ?>").removeAttr("disabled");
         	
         	$("time#m11_<?php echo $row->id; ?>").attr("onclick", 'morning_<?php echo $row->id; ?>("11.00am")');
         	$("time#m11_<?php echo $row->id; ?>").removeAttr("disabled");
         	
         	$("time#m12_<?php echo $row->id; ?>").attr("onclick", 'morning_<?php echo $row->id; ?>("12.00pm")');
         	$("time#m12_<?php echo $row->id; ?>").removeAttr("disabled");
         	
         	$("time#m11_<?php echo $row->id; ?>").attr("onclick", 'morning_<?php echo $row->id; ?>("11.00am")');
         	$("time#m11_<?php echo $row->id; ?>").removeAttr("disabled");
         	
         	
         	/**
         	 * validate values
         	 */
         	if(_morning<?php echo $row->id; ?>.val() == "10.00am") {
         		$("time#m10_<?php echo $row->id; ?>").removeAttr("onclick");
         		$("time#m10_<?php echo $row->id; ?>").attr("disabled", "disabled");
         	}
         	
         	if(_morning<?php echo $row->id; ?>.val() == "11.00am") {
         		$("time#m11_<?php echo $row->id; ?>").removeAttr("onclick");
         		$("time#m11_<?php echo $row->id; ?>").attr("disabled", "disabled");
         		
         		$("time#m10_<?php echo $row->id; ?>").removeAttr("onclick");
         		$("time#m10_<?php echo $row->id; ?>").attr("disabled", "disabled");
         	}
         	
         	if(_morning<?php echo $row->id; ?>.val() == "12.00pm") {
         		$("time#m12_<?php echo $row->id; ?>").removeAttr("onclick");
         		$("time#m12_<?php echo $row->id; ?>").attr("disabled", "disabled");
         		
         		$("time#m11_<?php echo $row->id; ?>").removeAttr("onclick");
         		$("time#m11_<?php echo $row->id; ?>").attr("disabled", "disabled");
         		
         		$("time#m10_<?php echo $row->id; ?>").removeAttr("onclick");
         		$("time#m10_<?php echo $row->id; ?>").attr("disabled", "disabled");
         	}         	
         	
         } //ends function
         
         
         function _morning<?php echo $row->id; ?>($time) {
         	var input_m = $("[contain=_morning<?php echo $row->id; ?>]");
         	input_m.val($time);
         	validate_morning<?php echo $row->id; ?>();
         }
         function morning_<?php echo $row->id; ?>($time) {
         	var input_m = $("[contain=morning_<?php echo $row->id; ?>]");
         	input_m.val($time);
         	validate_morning<?php echo $row->id; ?>();
         }

         
         
         /**
          * afternoon shift validation
          */
         function validate_afternoon<?php echo $row->id; ?>() {
         	var _afternoon<?php echo $row->id; ?> = $("[contain=_afternoon<?php echo $row->id; ?>]");
         	var afternoon_<?php echo $row->id; ?> = $("[contain=afternoon_<?php echo $row->id; ?>]");
         	/**
         	 * check two values if they are same
         	 */
         	if(_afternoon<?php echo $row->id; ?>.val() == afternoon_<?php echo $row->id; ?>.val()) {
         		afternoon_<?php echo $row->id; ?>.val("6.00pm");
         	}
         	
         	/**
         	 * set the default values
         	 */
         	$("time#af3_<?php echo $row->id; ?>").attr("onclick", 'afternoon_<?php echo $row->id; ?>("3.00pm")');
         	$("time#af3_<?php echo $row->id; ?>").removeAttr("disabled");
         	
         	$("time#af4_<?php echo $row->id; ?>").attr("onclick", 'afternoon_<?php echo $row->id; ?>("4.00pm")');
         	$("time#af4_<?php echo $row->id; ?>").removeAttr("disabled");
         	
         	$("time#af5_<?php echo $row->id; ?>").attr("onclick", 'afternoon_<?php echo $row->id; ?>("5.00pm")');
         	$("time#af5_<?php echo $row->id; ?>").removeAttr("disabled");
         	
         	$("time#af6_<?php echo $row->id; ?>").attr("onclick", 'afternoon_<?php echo $row->id; ?>("6.00pm")');
         	$("time#af6_<?php echo $row->id; ?>").removeAttr("disabled");
         	
         	
         	/**
         	 * validate values
         	 */
         	if(_afternoon<?php echo $row->id; ?>.val() == "3.00pm") {
         		$("time#af3_<?php echo $row->id; ?>").removeAttr("onclick");
         		$("time#af3_<?php echo $row->id; ?>").attr("disabled", "disabled");
         	}
         	
         	if(_afternoon<?php echo $row->id; ?>.val() == "4.00pm") {
         		$("time#af4_<?php echo $row->id; ?>").removeAttr("onclick");
         		$("time#af4_<?php echo $row->id; ?>").attr("disabled", "disabled");
         		
         		$("time#af3_<?php echo $row->id; ?>").removeAttr("onclick");
         		$("time#af3_<?php echo $row->id; ?>").attr("disabled", "disabled");
         	}
         	
         	if(_afternoon<?php echo $row->id; ?>.val() == "5.00pm") {
         		$("time#af5_<?php echo $row->id; ?>").removeAttr("onclick");
         		$("time#af5_<?php echo $row->id; ?>").attr("disabled", "disabled");
         		
         		$("time#af4_<?php echo $row->id; ?>").removeAttr("onclick");
         		$("time#af4_<?php echo $row->id; ?>").attr("disabled", "disabled");
         		
         		$("time#af3_<?php echo $row->id; ?>").removeAttr("onclick");
         		$("time#af3_<?php echo $row->id; ?>").attr("disabled", "disabled");
         	}         	
         	
         } //ends function
         
         
         function _afternoon<?php echo $row->id; ?>($time) {
         	var input_af = $("[contain=_afternoon<?php echo $row->id; ?>]");
         	input_af.val($time);
         	validate_afternoon<?php echo $row->id; ?>();
         }
         function afternoon_<?php echo $row->id; ?>($time) {
         	var input_af = $("[contain=afternoon_<?php echo $row->id; ?>]");
         	input_af.val($time);
         	validate_afternoon<?php echo $row->id; ?>();
         }
         
         </script>
         <tr>
           <form method="POST" action="?shift=<?php echo $shift; ?>">
             <input type='hidden' value='<?php echo $row->id; ?>' name="empid" />
            <td><?php echo $row->id; ?></td>
            <td onclick="location='employee.php?empid=<?php echo $row->id; ?>';"><?php echo $row->FullName; ?></td>
            <td><?php echo $row->Department; ?></td>
            
            
            <?php
            if($shift == "morning") {
            ?> 
            <!-- Morning shift -->
            <td>
            	<div class="dropdown" id="_morning">
            		<input type="text" class="tpicker" value="9.00am" contain="_morning<?php echo $row->id; ?>" name="m_start"/>
            		<div class="drop-menu">
            			<time onclick="_morning<?php echo $row->id; ?>('9.00am');">9.00am</time>
            			<time onclick="_morning<?php echo $row->id; ?>('10.00am');"></time>
            			<time onclick="_morning<?php echo $row->id; ?>('11.00am');">11.00am</time>
            			<time onclick="_morning<?php echo $row->id; ?>('12.00pm');">12.00pm</time>
            			<time disabled>1.00pm</time>
            		</div>
            	</div>
            	
            	<span>to</span>
            	
            	 <div class="dropdown" id="morning_">
            		<input type="text" class="tpicker" value="1.00pm" contain="morning_<?php echo $row->id; ?>" name="m_stop"/>
            		<div class="drop-menu">
            			<time disabled>9.00am</time>
            			<time onclick="morning_<?php echo $row->id; ?>('10.00am');" id="m10_<?php echo $row->id; ?>">10.00am</time>
            			<time onclick="morning_<?php echo $row->id; ?>('11.00am');" id="m11_<?php echo $row->id; ?>">11.00am</time>
            			<time onclick="morning_<?php echo $row->id; ?>('12.00pm');" id="m12_<?php echo $row->id; ?>">12.00pm</time>
            			<time onclick="morning_<?php echo $row->id; ?>('1.00pm');" id="m13_<?php echo $row->id; ?>">1.00pm</time>
            		</div>
            	</div>
            	
            </td>
            <?php
            } ?>
            
            
            <?php
            if($shift == "afternoon") {
            ?>
            <!-- Afternoon shift -->
            <td>
            	
            	<div class="dropdown" id="_afternoon">
            		<input type="text" class="tpicker" value="2.00pm" contain="_afternoon<?php echo $row->id; ?>" name="af_start"/>
            		<div class="drop-menu">
            			<time onclick="_afternoon<?php echo $row->id; ?>('2.00pm');">2.00pm</time>
            			<time onclick="_afternoon<?php echo $row->id; ?>('3.00pm');">3.00pm</time>
            			<time onclick="_afternoon<?php echo $row->id; ?>('4.00pm');">4.00pm</time>
            			<time onclick="_afternoon<?php echo $row->id; ?>('5.00pm');">5.00pm</time>
            			<time disabled>6.00pm</time>
            		</div>
            	</div>
            	
            	<span>to</span>
            	
            	 <div class="dropdown" id="afternoon_">
            		<input type="text" class="tpicker" value="6.00pm" contain="afternoon_<?php echo $row->id; ?>" name="af_stop"/>
            		<div class="drop-menu">
            			<time disabled>2.00pm</time>
            			<time onclick="afternoon_<?php echo $row->id; ?>('3.00pm');" id="af3_<?php echo $row->id; ?>">3.00pm</time>
            			<time onclick="afternoon_<?php echo $row->id; ?>('4.00pm');" id="af4_<?php echo $row->id; ?>">4.00pm</time>
            			<time onclick="afternoon_<?php echo $row->id; ?>('5.00pm');" id="af5_<?php echo $row->id; ?>">5.00pm</time>
            			<time onclick="afternoon_<?php echo $row->id; ?>('6.00pm');" id="af6_<?php echo $row->id; ?>">6.00pm</time>
            		</div>
            	</div>
            	
            </td>
            <?php
            } ?>
            <td class="option">
               <input type="checkbox" id="presence<?php echo $row->id; ?>" name="presence"/>
               <label for="presence<?php echo $row->id; ?>"></label>
            </td>
            <td>
              <button class="waves-effect waves-light savebtn teal" type="submit" name="attendance">Save</button>
            </td>
            </form>
         </tr>
         <?php
           }
          }
         ?>
         </tbody>
      </table>
      <?php
        } else {
        	  echo '
        	  
        	    <div class="row white" style="border-bottom: 1px solid #a6a6a6; margin: 0;">
   		<div class="col s6" style="text-align: left; padding: 9px;">
   			<b><a href="today_attendance.php" class="teal-text">TODAY&#39;S ATTENDANCE</a></b>
   		</div>
   	</div>
        	    <div style="padding: 70px; text-align: center; border-bottom: 1px solid #a6a6a6; color: grey;">
        	      <b>#TimeOut,   You can call attendance from 9.00am to 6.00pm</b>
        	    </div>
        	  ';
        }
       ?>
   </body>
</html>
<?php
  //database configuration ffile
  $host = "localhost"; //host
  $user = "root"; //username
  $pass = ""; //password
  $db = "attendance_system";  //db name
  
  $sql = new mysqli($host, $user, $pass);
  $sql->select_db($db) || EAS_ERRORS::Warning("Could not select mysql database! MySQL connection returned 0 and said: <b>".mysqli_error($sql)."</b>");
?>
<?php
  //Configuration file
  require 'db.config.php';
  date_default_timezone_set("Asia/Dhaka");
  
  function CountHours($timestr) {
  	   $date = $timestr;
  	   $result = explode("&", $date);
  	   $range1 = explode("-", ltrim($result[0]));
  	   $time1 = new DateTime(date('H:i:s',strtotime($range1[0])));
  	   $time2 = new DateTime(date('H:i:s',strtotime($range1[1])));
  	   $diff1 = $time1->diff($time2);
  	   $range2 = explode("-", ltrim($result[1]));
  	   $time3 = new DateTime(date('H:i:s',strtotime($range2[0])));
  	   $time4 = new DateTime(date('H:i:s',strtotime($range2[1])));
  	   $diff2 = $time3->diff($time4);
  	   $total_hours = ($diff1->h + $diff2->h);
  	   
  	   return $total_hours;
  }
  
  
  
  
      /**
   * Function timestamp() identifies the timestamp by arrays of
   * timestamp @params    string $time
   * @params   string $now  which requires now()
  */

  function timestamp($time) {
  /* String $periods    loads an array for call the timestamp
   * @params    string $time
   * @params    string $now
  */
     $periods = array("second", "minute", "hour", "day", "week", "month", "year", "decade"); 

  /* We count the lengths of the timestamp from the parameter
   * @params    string $lengths
   * @params    string $now
  */
     $lengths = array("60","60","24","7","4.35","12","10");

  /* We have a variable @params  string $now */
     $now = time();

  /* We count the difference between $now & $time
   * @params   string $time &
   * @params   string $now
   * we minus $now-$time
  */
     $difference = $now - $time; 

     for($j = 0; $difference >= $lengths[$j] && $j < count($lengths)-1; $j++)
      { $difference /= $lengths[$j]; } 

 /* Return a variable $difference @param  string prev $difference
 */
     $difference = round($difference);
     if($difference != 1 && $difference != 0)
       {
         /* return to @params   string $periods while [$j] is not a singular number
          * we add 's' after     string $periods
         */
         $periods[$j].= "s";
       }
     /* Return a string $difference & $periods while $j is sigular or plural */

     $timestamp="$difference $periods[$j] ago";
     
     /**
      * research the timestamp as we care a special timestamp for bbuzz
      * this library may help us very much for getting a proper timestamp
      */
     if(
       $timestamp == "0 second ago"          ||
       $timestamp == "1 second ago"          ||
       $timestamp == "2 seconds ago"        ||
       $timestamp == "3 seconds ago"          ||
       $timestamp == "4 seconds ago"          ||
       $timestamp == "5 seconds ago"          ||
       $timestamp == "6 seconds ago"          ||
       $timestamp == "7 seconds ago"          ||
       $timestamp == "8 seconds ago"          ||
       $timestamp == "9 seconds ago"          ||
       $timestamp == "10 seconds ago"          ||
       $timestamp == "11 seconds ago"          ||
       $timestamp == "12 seconds ago"          ||
       $timestamp == "13 seconds ago"          ||
       $timestamp == "14 seconds ago"          ||
       $timestamp == "15 seconds ago"          ||
       $timestamp == "16 seconds ago"          ||
       $timestamp == "17 seconds ago"          ||
       $timestamp == "18 seconds ago"          ||
       $timestamp == "19 seconds ago"          ||
       $timestamp == "20 seconds ago"          ||
       $timestamp == "21 seconds ago"          ||
       $timestamp == "22 seconds ago"          ||
       $timestamp == "23 seconds ago"          ||
       $timestamp == "24 seconds ago"          ||
       $timestamp == "25 seconds ago"          ||
       $timestamp == "26 seconds ago"          ||
       $timestamp == "27 seconds ago"          ||
       $timestamp == "28 seconds ago"          ||
       $timestamp == "29 seconds ago"          ||
       $timestamp == "30 seconds ago"          ||
       $timestamp == "31 seconds ago"          ||
       $timestamp == "32 seconds ago"          ||
       $timestamp == "33 seconds ago"          ||
       $timestamp == "34 seconds ago"          ||
       $timestamp == "35 seconds ago"          ||
       $timestamp == "36 seconds ago"          ||
       $timestamp == "37 seconds ago"          ||
       $timestamp == "38 seconds ago"          ||
       $timestamp == "39 seconds ago"          ||
       $timestamp == "40 seconds ago"          ||
       $timestamp == "41 seconds ago"          ||
       $timestamp == "42 seconds ago"          ||
       $timestamp == "43 seconds ago"          ||
       $timestamp == "44 seconds ago"          ||
       $timestamp == "45 seconds ago"          ||
       $timestamp == "46 seconds ago"          ||
       $timestamp == "47 seconds ago"          ||
       $timestamp == "48 seconds ago"          ||
       $timestamp == "49 seconds ago"          ||
       $timestamp == "50 seconds ago"          ||
       $timestamp == "51 seconds ago"          ||
       $timestamp == "52 seconds ago"          ||
       $timestamp == "53 seconds ago"          ||
       $timestamp == "54 seconds ago"          ||
       $timestamp == "55 seconds ago"          ||
       $timestamp == "56 seconds ago"          ||
       $timestamp == "57 seconds ago"          ||
       $timestamp == "58 seconds ago"          ||
       $timestamp == "59 seconds ago"          ||
       $timestamp == "60 seconds ago"          
     )
     {
     	/**
     	 * @return void,      return just now message if the previous rules are done, 
     	 * else we return the normal timestamp as default
     	 */
     	return "Just now";
     }
     else {
     	if($timestamp == "1 day ago")
     	{
     		/**
     		 * @return void 
     		 * return yesterday as 1 day means the last day
     		 */
     		return "Yesterday";
     	}
     	else {
     		     	 /**
     	          * @return void,    return the normal timestamp as default
     	          * as the previous rules are not done
     	          */
     	         return $timestamp;
     	}
     	
     } //end else if


} //end function
?>
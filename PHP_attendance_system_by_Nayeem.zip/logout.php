<?php
   /**
    * @logout, an admin
    * @package EAS
    */
   session_start();
   if(session_destroy()) {
   	echo '
   	  <script>window.location.replace("index.php?q_=login&__");</script>
   	';
   }
?>
CREATE TABLE IF NOT EXISTS `employees` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `FirstName` varchar(50) NOT NULL,
  `LastName` varchar(50) NOT NULL,
  `FullName` varchar(100) NOT NULL,
  `Age` varchar(3) NOT NULL,
  `BloodGroup` varchar(4) NOT NULL,
  `Address` longtext NOT NULL,
  `Phone` varchar(20) NOT NULL,
  `Department` varchar(50) NOT NULL,
  `Salary` varchar(100) NOT NULL,
  `Email` varchar(60) NOT NULL,
  `JoinDate` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `Email` (`Email`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=0 ;

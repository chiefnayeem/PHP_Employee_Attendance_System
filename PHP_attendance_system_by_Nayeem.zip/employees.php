<?php
 /**
  * List of all Employees in a table to be printed
  *
  * @package EAS
  */
 require './@config/config.php';
 require './@config/db.config.php';
 require './libs/class.error.php';
 require './libs/class.config.php';
 
?><!DOCTYPE html>
<html lang="en">
   <head>
      <meta charset="utf-8">
      <meta name="viewport" content="initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no"> 
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="msapplication-tap-highlight" content="no">
      <meta name="theme-color" content="#607d8b">
      <link rel="STYLESHEET" href="./res/css/materialize.min.css"/>
      <link rel="STYLESHEET" href="./res/css/font-awesome.min.css" />
      <script src="./res/js/jquery.min.js"></script>
      <script src="./res/js/materialize.min.js"></script>
      <style>
      	table.responsive-table {
            margin-left: 10px;
            margin-right: 10px;
            margin-top: 10px;
            width:97.9%;
            border-radius: 2px;
            border: 1px solid #a6a6a6;
         }
         table.responsive-table th, td {
            padding: 15px 18px;
         }
         table.responsive-table td.option {
            color: #009688;
         }
         
      </style>
   </head>
   <body>
   	<div class="row white" style="border-bottom: 1px solid #a6a6a6; margin: 0;">
   		<div class="col s6" style="text-align: left; padding: 9px;">
   			<b>EMPLOYEES</b>
   		</div>
   		<div class="col s6" style="text-align: right; padding: 0px;">
   		<form method="GET" action="">
   			<input type="search" style="margin: 0; padding: 0px; width: 50%; background-image: url('./res/icons/searchicon.png'); background-repeat: no-repeat; background-position: 12px 12px; padding-left: 40px;" placeholder="Search an employee" class="teal-text" name="query" value="<?php echo $_GET["query"]; ?>"/>
   			</form>
   		</div>
   	</div>
   	
   	
      <table class="striped highlight" style="border: 1px solid grey; width: 100%;">
         <thead>
         <tr>
            <th data-field="id">ID</th>
            <th data-field="name">Name</th>
            <th data-field="price">Address</th>
            <th data-field="price">Email</th>
            <th data-field="price">Mobile</th>
            <th data-field="price">Department</th>
         </tr>
         </thead>

         <tbody>
         <?php
           if(isset($_GET["query"])) {
           	  $sq = $_GET["query"];
           	  $query = "SELECT * FROM employees WHERE FullName LIKE '%$sq%' OR Email LIKE '%$sq%' OR id LIKE '%$sq%' OR Phone LIKE '%$sq'";
           } else {
           	 $query = "SELECT * FROM employees";
           }
           $excution = $sql->query($query);
           if(mysqli_num_rows($excution)) {
           while($row = mysqli_fetch_object($excution)) {
           	?>
           	<tr onclick="location='employee.php?empid=<?php echo $row->id; ?>';">
            <td><?php echo $row->id; ?></td>
            <td><?php echo $row->FirstName." ".$row->LastName; ?></td>
            <td><?php echo $row->Address; ?></td>
            <td><?php echo $row->Email; ?></td>
            <td><?php echo $row->Phone; ?></td>
            <td><?php echo $row->Department; ?></td>
           </tr>
           <?php
           }
           
           } else {
           ?>
            <tr>
               <td colspan="6" style="background: #ffffff; text-align: center; padding: 40px;">No employees</td>
            </tr>
           <?php
           }
         ?>
         </tbody>
      </table>
   </body>
</html>
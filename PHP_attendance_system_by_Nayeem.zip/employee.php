<?php
 /**
  * List of all Employees in a table to be printed
  *
  * @package EAS
  */
 require './@config/config.php';
 require './@config/db.config.php';
 require './libs/class.error.php';
 require './libs/class.config.php';
 require './libs/class.employee.php';
 require './libs/class.salary.php';
 
 $empid = $_GET["empid"];
 $emp = EAS_EMPLOYEE::ID($empid);
?><!DOCTYPE html>
<html lang="en">
   <head>
      <title>Employee</title>
      <meta charset="utf-8">
      <!--<meta name="viewport" content="initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no"> -->
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="msapplication-tap-highlight" content="no">
      <meta name="theme-color" content="#607d8b">
      <link rel="STYLESHEET" href="./res/css/materialize.min.css"/>
      <link rel="STYLESHEET" href="./res/css/font-awesome.min.css" />
      <script src="./res/js/jquery.min.js"></script>
      <script src="./res/js/materialize.min.js"></script>
      <script>
      	function goBack() {
      		window.history.back();
      	}
      	
      	function confirmation() {
      		var r=confirm("Do you really want to delete this employee?");
      		if (r==true) {
      			$.ajax({
      				url: 'delete_employee.php?empid=<?php echo $empid; ?>',
      				type: 'GET',
      				dataType: 'text',
      				cache: false,
      				success: function(result) {
      					if(result == 1) {
      						alert("Successfully deleted this employee! Please refresh this page!");
      						goBack();
      					} else if(result == 0) {
      						alert("Error deleting this employee!");
      					}
      				},
      				error: function() {
      					alert("Error deleting this employee!");
      				}
      			})
      		}
      	}
      </script>
      <style>
      	h4.center {
      		font-weight: bold;
      	}
      	
      	.salary {
      		position: relative;
      		display: inline-block;
      	}
      	.salary .tooltip {
      		position: absolute;
      		z-index: 9999;
      		padding: 5px;
      		background: black;
      		color: white;
      		top: -35px; left: 10%;
      		display: block;
      		width: 130px;
      		border-radius: 2px;
      		text-align: center;
      		display: none;
      	}
      	.salary .tooltip::after {
    content: " ";
    position: absolute;
    top: 100%; /* At the bottom of the tooltip */
    left: 10%;
    margin-left: -5px;
    border-width: 5px;
    border-style: solid;
    border-color: black transparent transparent transparent;
}
      	.salary:hover .tooltip {
      		display: block;
      	}
      </style>
   </head>
   <body>
      <div class="row white" style="border-bottom: 1px solid #a6a6a6; margin: 0;">
   		<div class="col s6" style="text-align: left; padding: 0;">
   			<b class="waves-effect waves-default fa fa-arrow-left" onclick='goBack();' style="padding: 11px;">&nbsp; Back to the list</b>
   		</div>
   	</div>
   	
   	<div class="row white z-depth-2" style="border: 1px solid #dddddd; margin: 5%; margin-left: 25%; margin-right: 25%; border-radius: 3px; ">
   		<div style="padding: 20px;">
   			<h4 class="center" style="font-size: 22px;"><?php echo $emp["FullName"]; ?></h4>
   			
   			
   			
   			<table class="bordered striped emp" style="width: 100%; border: 1px dashed #a6a6a6;">
   			  <tbody>
   			    <tr>
   			      <th>ID</th>
   			      <td><?php echo $emp["id"]; ?> (UNIQUE)</td>
   			    </tr>
   			    <tr>
   			      <th>Name</th>
   			      <td><?php echo $emp["FullName"]; ?></td>
   			    </tr>
   			    <tr>
   			      <th>Age</th>
   			      <td><?php echo $emp["Age"]; ?></td>
   			    </tr>
   			    <tr>
   			      <th>Blood Group</th>
   			      <td><?php echo $emp["BloodGroup"]; ?></td>
   			    </tr>
   			    <tr>
   			      <th>Phone</th>
   			      <td><?php echo $emp["Phone"]; ?></td>
   			    </tr>
   			    <tr>
   			      <th>Email</th>
   			      <td><?php echo $emp["Email"]; ?></td>
   			    </tr>
   			    <tr>
   			      <th>Address</th>
   			      <td><?php echo $emp["Address"]; ?></td>
   			    </tr>
   			    <tr>
   			      <th>Department</th>
   			      <td><?php echo $emp["Department"]; ?></td>
   			    </tr>
   			    <tr>
   			      <th>Salary</th>
   			      <td><?php echo $emp["Salary"]; ?></td>
   			    </tr>
   			    <tr>
   			      <th>Joined on</th>
   			      <td><?php echo date('d M, Y', $emp["JoinDate"]); ?></td>
   			    </tr>
   			  </tbody>
   			</table>
   			<a class="waves-effect waves-light btn" style="width: 49%;" href="./edit_emp.php?empid=<?php echo $emp['id']; ?>"><span class="fa fa-edit">&nbsp; </span> Edit</a>
   			<a class="waves-effect waves-light btn" style="width: 50%;" onclick="confirmation();"><span class="fa fa-trash-o">&nbsp; </span>Delete</a>
   			
   			<hr></hr>
   			
   			<b>THIS MONTH ATTENDANCE</b>
   			<table class="striped">
   				<thead>
   					<tr>
   						<th data-field="id">Day</th>
   						<th data-field="name">Morning</th>
   						<th data-field="name">Afternoon</th>
   						<th data-field="name">Salary</th>
   					</tr>
   				</thead>
   				<tbody>
   				<?php
   				  $month = date('M', time());
   				  $year = date('Y', time());
   				  $query = "SELECT * FROM attendance WHERE EMP_ID='{$empid}' AND Month='{$month}' AND Year='{$year}'";
   				  $excution = $sql->query($query);
   				  if(mysqli_num_rows($excution)) {
   				  	 while($row = mysqli_fetch_object($excution))
   				  	 {
   				  	 	$shifts = explode("&", $row->Attendance);
   				  	 	$morning = ltrim($shifts[0]);
   				  	 	$afternoon = ltrim($shifts[1]);
   				  	 	if($morning == null) {
   				  	 		$morning = "<span class='red-text'>absent</span>";
   				  	 	}
   				  	 	if($afternoon == null) {
   				  	 		$afternoon = "<span class='red-text'>absent</span>";
   				  	 	}
   				  	 	$worked = CountHours($row->Attendance);
   				 ?>
   				   <tr>
   						<td><?php echo $row->Day." ".$row->Month.", ".$row->Year; ?></td>
   						<td><?php echo $morning; ?></td>
   						<td><?php echo $afternoon; ?></td>
   						<td>
   						  <div class="salary <?php if($worked == 8) { echo 'green-text'; } elseif($worked == 0) { echo 'red-text'; } ?>" style="color: <?php if($worked) { echo '#ff8f00'; } ?>">
   						    <?php echo EAS_SALARY::CountByHours($emp["Salary"], CountHours($row->Attendance)); ?>
   						    <div class="tooltip"><?php if(CountHours($row->Attendance) > 1) { echo CountHours($row->Attendance)." hours"; } else { echo CountHours($row->Attendance)." hour"; } ?>&nbsp;worked</div>
   						  </div>
   						</td>
   					</tr>
   				 <?php
   				  	 }
   				  }
   				?>
   				</tbody>
   				<tfoot>
   					<tr>
   						<th colspan="2" style="text-align: center">Total worked = <?php echo EAS_SALARY:: AttendanceAndSalaryInfo($empid, $month, $year)["WORKED"]; ?></td>
   						<th colspan="2" style="text-align: center">Total salary = <?php echo EAS_SALARY:: AttendanceAndSalaryInfo($empid, $month, $year)["TOTAL_SALARY"]; ?></td>
   					</tr>
   				</tfoot>
   			</table>
   		</div>
   	</div>
   </body>
</html>
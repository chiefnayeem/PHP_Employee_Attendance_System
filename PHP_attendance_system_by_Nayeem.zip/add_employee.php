<?php
 /**
  * @employee registration, using html form
  *
  * @package EAS
  */
 require './@config/config.php';
 require './libs/class.error.php';
 require './libs/class.config.php';
 
 if(isset($_POST["register_emp"]))
 {
 	 $data = $_POST; //array var
 	 $fname = ltrim($data["fname"]);
 	 $lname = ltrim($data["lname"]);
 	 $fullname = $fname." ".$lname;
 	 $age = ltrim($data["age"]);
 	 $mobile = ltrim($data["mobile"]);
 	 $email = ltrim($data["email"]);
 	 $blood = ltrim($data["blood"]);
 	 $address = addslashes(ltrim($data["address"]));
 	 $department = ltrim($data["department"]);
 	 $salary = ltrim($data["salary"]);
 	 
 	 //validate duplications
 	 $query = "SELECT * FROM employees WHERE Email='{$email}'";
 	 if(mysqli_num_rows($sql->query($query)))
 	 {
 	 	EAS_ERRORS::JSAlert("This employee was registered before! Change the email!");
 	 } else {
 	 	$now = time();
 	 	$query = "INSERT INTO employees (FirstName, LastName, FullName, Age, BloodGroup, Address, Phone, Department, Salary, Email, JoinDate) VALUES ('$fname', '$lname', '$fullname', '$age', '$blood', '$address', '$mobile', '$department', '$salary', '$email', '$now')";
 	 	
 	 	if($sql->query($query)) {
 	 		EAS_ERRORS::JSAlert("Employee registered successfully!");
 	 	} else {
 	 		EAS_ERRORS::Warning(mysqli_error($sql));
 	 	}
 	 }
 } //end if
?><!DOCTYPE html>
<html lang="en">
   <head>
      <meta charset="utf-8">
      <meta name="viewport" content="initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no"> 
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="msapplication-tap-highlight" content="no">
      <meta name="theme-color" content="#607d8b">
      <link rel="STYLESHEET" href="./res/css/materialize.min.css"/>
      <link rel="STYLESHEET" href="./res/css/font-awesome.min.css" />
      <script src="./res/js/jquery.min.js"></script>
      <script src="./res/js/materialize.min.js"></script>
      <script>
         $(document).ready(function() {
            Materialize.updateTextFields();
            $('select').material_select();
            $('.modal').modal();
         });
         
         /**
          * modal alert
          */
         function malert($title, $msg) {
            	$(document).ready(function(){
            		$('#modal').modal('open');
            		$('.modal [contain=title]').text($title);
            		$('.modal [contain=msg]').text($msg);
            	});
         }
         
         function validateRegForm() {
            var fname = document.forms["RegisterEmployee"]["fname"].value,
                    lname = document.forms["RegisterEmployee"]["lname"].value,
                    age = document.forms["RegisterEmployee"]["age"].value,
                    mobile = document.forms["RegisterEmployee"]["mobile"].value,
                    email = document.forms["RegisterEmployee"]["email"].value,
                    blood = document.forms["RegisterEmployee"]["blood"].value,
                    department = document.forms["RegisterEmployee"]["department"].value,
                    address = document.forms["RegisterEmployee"]["address"].value,
                    salary = document.forms["RegisterEmployee"]["salary"].value;

            if(fname.trim() == "") {
               malert("Form validation", "First name is required! ");
               document.getElementById("first_name").style = "border-bottom: 2px solid red;";
               return false;
            } else {
               document.getElementById("first_name").style = "border-bottom: 1px solid #2e7d32;";
            }
            if(lname.trim() == "") {
               malert("Form validation", " Last name is required! ");
               document.getElementById("last_name").style = "border-bottom: 2px solid red;";
               return false;
            } else {
               document.getElementById("last_name").style = "border-bottom: 1px solid #2e7d32;";
            }
            
            if(age.trim() == "") {
               malert("Form validation", "Enter the age of this employee!");
               document.getElementById("age").style = "border-bottom: 2px solid red;";
               return false;
            } else {
               document.getElementById("age").style = "border-bottom: 1px solid #2e7d32;";
            }
            
            
            
            if(mobile.trim() == "") {
               malert("Form validation", " Mobile number is required! ");
               document.getElementById("number").style = "border-bottom: 2px solid red;";
               return false;
            } else {
               document.getElementById("number").style = "border-bottom: 1px solid #2e7d32;";
            }
            if(email.trim() == "") {
               malert("Form validation", " Email is required! ");
               document.getElementById("email").style = "border-bottom: 2px solid red;";
               return false;
            } else {
               document.getElementById("email").style = "border-bottom: 1px solid #2e7d32;";
            }
            if(blood.trim() == "") {
               malert("Form validation", " Select a blood group! ");
               document.getElementById("blood").style = "border-bottom: 2px solid red;";
               return false;
            } else {
               document.getElementById("blood").style = "border-bottom: 1px solid #2e7d32;";
            }
            if(department.trim() == "") {
               malert("Form validation", " Select a department! ");
               document.getElementById("department").style = "border-bottom: 2px solid red;";
               return false;
            } else {
               document.getElementById("department").style = "border-bottom: 1px solid #2e7d32;";
            }
            if(address.trim() == "") {
               malert("Form validation", "Employee's address is required! ");
               document.getElementById("address").style = "border-bottom: 2px solid red;";
               return false;
            } else {
               document.getElementById("address").style = "border-bottom: 1px solid #2e7d32;";
            }
            if(salary.trim() == "") {
               malert("Form validation", "Enter the salary of this employee");
               document.getElementById("salary").style = "border-bottom: 2px solid red;";
               return false;
            } else {
               document.getElementById("salary").style = "border-bottom: 1px solid #2e7d32;";
            }
         }
      </script>
      <style>
      	h4 {color: grey;}
      </style>
   </head>
   <body>
      <div class="row">
         <div class="col s12 m5" style="width: 89%; margin: 60px; margin-top: 10px;">
            <fieldset class="card-panel white" style="color: black;">
            	<legend><h4>Register Employee</h4></legend>

               <!-- reister employees, forms -->
               <div class="row">
                  <form class="col s12" name="RegisterEmployee" onSubmit="return validateRegForm();" method="POST">
                     <div class="row">
                        <div class="input-field col s6">
                           <input id="first_name" type="text" class="validate" name="fname">
                           <label for="first_name">First Name</label>
                        </div>
                        <div class="input-field col s6">
                           <input id="last_name" type="text" class="validate" name="lname">
                           <label for="last_name">Last Name</label>
                        </div>
                     </div>
                     
                     <!-- Age -->
                     <div class="row">
                        <div class="input-field col s12">
                           <input id="age" type="number" class="validate" name="age">
                           <label for="age">Age</label>
                        </div>
                     </div>
                     
                     <div class="row">
                        <div class="input-field col s12">
                           <input id="number" type="number" class="validate" name="mobile">
                           <label for="number">Mobile number</label>
                        </div>
                     </div>
                     <div class="row">
                        <div class="input-field col s12">
                           <input id="email" type="email" class="validate" name="email">
                           <label for="email">Email</label>
                        </div>
                     </div>

                     <!-- Select menu -->
                     <div class="input-field col s12">
                        <select name="blood" id="blood">
                           <option value="" disabled selected>Select blood group</option>
                           <option value="A+">A +</option>
                           <option value="A-">A -</option>
                           <option value="B+">B +</option>
                           <option value="AB+">AB +</option>
                           <option value="AB-">AB -</option>
                           <option value="O+">O +</option>
                           <option value="O-">O -</option>
                        </select>
                        <label>Blood group</label>
                     </div>
                     <div class="input-field col s12">
                        <select name="department" id="department">
                        <?php
                         $deps = EAS_CONFIG::getDepartments();
                        ?>
                           <option value="" disabled selected>Select department</option>
                           <?php
                            foreach($deps as $dep) {
                            	 echo '<option value="'.$dep.'">'.$dep.'</option>';
                            }
                           ?>
                        </select>
                        <label>Depaertment</label>
                     </div>

                     <!-- Address -->
                     <div class="row">
                        <div class="row">
                           <div class="input-field col s12">
                              <textarea id="address" class="materialize-textarea" name="address"></textarea>
                              <label for="address">Address</label>
                           </div>
                        </div>
                     </div>
                     
                     <!-- Salary -->
                     <div class="row">
                        <div class="input-field col s12">
                           <input id="salary" type="number" class="validate" name="salary">
                           <label for="salary">Salary</label>
                        </div>
                     </div>
                     
                     <input type="submit" class="waves-effect waves-light btn" value="Register Employee" name="register_emp" />
                  </form>
               </div>
               <!-- Input types ends -->


            </fieldset>
         </div>
      </div>
      
      
      <!-- Modal  -->
      <div id="modal" class="modal">
      	<div class="modal-content">
      		<h4 contain="title"></h4>
      		<p contain="msg"></p>
      	</div>
      	<div class="modal-footer">
      		<a href="#!" class=" modal-action modal-close waves-effect waves-teal btn-flat">Ok</a>
      	</div>
      </div>
      <!-- Modal ends -->
   </body>
</html>
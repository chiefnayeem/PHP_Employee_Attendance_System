<?php
 /**
  * Salary slip of an employee, From attendance caller
  *
  * @package EAS
  */
 session_start();
 require './@config/config.php';
 require './@config/db.config.php';
 require './libs/class.error.php';
 require './libs/class.config.php';
 require './libs/class.employee.php';
 require './libs/class.salary.php';
 
 $empid = $_GET["empid"];
 $emp = EAS_EMPLOYEE::ID($empid);
?><!DOCTYPE html>
<html lang="en">
   <head>
      <title>Salary</title>
      <style>
          body {
              text-align: center;
              font-family: Aharoni;
          }
      	table {
      		border-collapse: collapse;
      		width: 100%;
            border-color: grey;
      	}
          div.cont {
              padding: 10px;
              background: white;
              border: 1px solid #a6a6a6;
              display: inline-block;
              width: 600px;
              word-break: break-all;
              text-align: center;
              borde-radius: 2px;
          }
          h3, h4 {
              font-family: Aharoni;
              margin: 0;
              display: block;
          }
          h3.logo {
              font-size: 23px;
          }
          .header {
              text-align: center;
              font-size: 18px;
              font-family: Aharoni;
              margin-top: 20px;
              margin-bottom: 20px;
              background: black;
              color: white;
              display: inline-block;
              padding: 6px;
              border-radius: 2px;
              text-transform: capitalize;
          }
          h4.text {
              text-align: left;
          }

          button {
              background: #00999b;
              border: 0;
              padding: 5px 10px;
              color: white;
              border-radius: 2px;
          }
          button:hover {
              background: white;
              color: #00999b;
              border: 1px solid #a6a6a6;
          }
    </style>
   </head>
   <body>
     <div class="cont">
         <h3 class="logo"><?php echo EAS_CONFIG::getAppName(); ?></h3>
         <h4>
             <?php echo EAS_CONFIG::getAddress(); ?>
             <br/>
             Web: <?php echo EAS_CONFIG::getWebsite(); ?>
             <br/>
             Phone: <?php echo EAS_CONFIG::getPhone(); ?>
         </h4>

         <div class="header"><?php echo $emp["FullName"]; ?></div>

         <div style="display: block; text-align: left; margin-bottom: 15px;">
             <table border="1" style="text-align: center">
                 <tr>
                     <th>ID</th>
                     <th>Department</th>
                     <th>Salary</th>
                 </tr>
                 <tr>
                     <td><?php echo $emp["id"]; ?></td>
                     <td><?php echo $emp["Department"]; ?></td>
                     <td><?php echo $emp["Salary"]; ?></td>
                 </tr>
             </table>
         </div>

         <h4 class="text">Salary according to the attendances </h4>
         <table border="1">
             <thead>
               <tr>
                   <th>Day</th>
                   <th>Month</th>
                   <th>Year</th>
                   <th>Morning</th>
                   <th>Afternoon</th>
                   <th>Worked</th>
               </tr>
             </thead>

             <tbody>
           	  <?php
   				  $month = date('M', time());
   				  $year = date('Y', time());
   				  $query = "SELECT * FROM attendance WHERE EMP_ID='{$empid}' AND Month='{$month}' AND Year='{$year}'";
   				  $excution = $sql->query($query);
   				  if(mysqli_num_rows($excution)) {
   				  	 while($row = mysqli_fetch_object($excution))
   				  	 {
   				  	 	$shifts = explode("&", $row->Attendance);
   				  	 	$morning = ltrim($shifts[0]);
   				  	 	$afternoon = ltrim($shifts[1]);
   				  	 	if($morning == null) {
   				  	 		$morning = "<span class='red-text'>absent</span>";
   				  	 	}
   				  	 	if($afternoon == null) {
   				  	 		$afternoon = "<span class='red-text'>absent</span>";
   				  	 	}
   				  	 	$worked = CountHours($row->Attendance);
   				  	 	?>
               <tr>
                   <td><?php echo $row->Day; ?></td>
                   <td><?php echo $row->Month; ?></td>
                   <td><?php echo $row->Year; ?></td>
                   <td><?php echo $morning; ?></td>
                   <td><?php echo $afternoon; ?></td>
                   <td><?php if(CountHours($row->Attendance) > 1) { echo CountHours($row->Attendance)." hours"; } else { echo CountHours($row->Attendance)." hour"; } ?></td>
               </tr>
               <?php
                  }
                } else {
               ?>
               <tr>
                   <td colspan="6" style="padding: 20px;">No attendance </td>
               </tr>
               <?php
                }
               ?>
             </tbody>
         </table>
         
         
         
         
         <table border="1" style="border-top: 1px solid transparent;">
             <tr>
                 <th>Worked = <?php echo EAS_SALARY:: AttendanceAndSalaryInfo($empid, $month, $year)["WORKED"]; ?></th>
                 <th>Total salary = <?php echo EAS_SALARY:: AttendanceAndSalaryInfo($empid, $month, $year)["TOTAL_SALARY"]; ?></th>
             </tr>
         </table>
         <br/>
         <div style="text-align: left; font-family: arial; font-size: 15px;">
             <b>Date:</b> <?php echo date('d', time())." ".$month.", ".$year; ?> <br/>
             <b>Salary status:</b> Paid <br/>
             <b>MD5 Signature:</b> <?php $admin = mysqli_fetch_array($sql->query("SELECT * FROM users WHERE Email='$_SESSION[Email]'"));
             echo $admin["FirstName"]." ".$admin["LastName"];
            ?>
         </div>
         <div style="text-align: right; color: grey; font-size: 14px;">Salary Slip</div>
     </div>

   <div style="position: fixed; bottom: 5%; right: 5%;">
       <button onclick="window.print();">Print</button>
   </div>
   </body>
</html>
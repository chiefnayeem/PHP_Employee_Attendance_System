<?php
 /**
  * Attendance caller, List of all Employees in a table to be printed
  *
  * @package EAS
  */
 require './@config/config.php';
 require './@config/db.config.php';
 require './libs/class.error.php';
 require './libs/class.config.php';
 require './libs/class.employee.php';
?><!DOCTYPE html>
<html lang="en">
   <head>
      <title>Todays attendance</title>
      <meta charset="utf-8">
      <!--<meta name="viewport" content="initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no"> -->
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="msapplication-tap-highlight" content="no">
      <meta name="theme-color" content="#607d8b">
      <link rel="STYLESHEET" href="./res/css/materialize.min.css"/>
      <link rel="STYLESHEET" href="./res/css/font-awesome.min.css" />
      <script src="./res/js/jquery.min.js"></script>
      <script src="./res/js/materialize.min.js"></script>
      <script>
      	function goBack() {
      		window.history.back();
      	}
      </script>
   </head>
   <body>
      <div class="row white" style="border-bottom: 1px solid #a6a6a6; margin: 0;">
   		<div class="col s6" style="text-align: left; padding: 0;">
   			<b class="waves-effect waves-default fa fa-arrow-left" onclick='goBack();' style="padding: 11px;">&nbsp; Back to the list</b>
   		</div>
   	</div>
   	
   	<table class="bordered striped" style="width: 100%;">
   	  <thead>
   	    <tr>
   	      <th>ID</th>
   	      <th>Name</th>
   	      <th>Department</th>
   	      <th>Presence</th>
   	      <th>Last Updated</th>
   	    </tr>
   	  </thead>
   	  <tbody>
   	    <?php
   	      $day = date('d', time());
   	      $month = date('M', time());
   	      $year = date('Y', time());
   	      $query = $sql->query("SELECT * FROM attendance WHERE Day='{$day}' AND Month='{$month}' AND Year='{$year}'");
   	      if(mysqli_num_rows($query)) {
   	      	while($row = mysqli_fetch_array($query))
   	      	{
   	      		$empid = $row["EMP_ID"];
   	      		$emp = EAS_EMPLOYEE::ID($empid);
   	      		$att = $row["Attendance"];
   	      		$shifts = explode("&", $att);
   	      		$morning = ltrim($shifts[0]);
   	      		$afternoon = ltrim($shifts[1]);
   	      		
   	      		if($morning == null) {
   	      			$morning = "<font color='red'>absent</font>";
   	      		}
   	      		if($afternoon == null) {
   	      			$afternoon = "<font color='red'>absent</select>";
   	      		}
   	      		$att = "<b>Morning</b>: ".$morning." &nbsp;&nbsp;<b>Afternoon</b>: ".$afternoon;
   	      		
   	     ?>
   	    <tr onclick='location="employee.php?empid=<?php echo $empid; ?>"; '>
   	      <td><?php echo $emp["id"]; ?></td>
   	      <td><?php echo $emp["FullName"]; ?></td>
   	      <td><?php echo $emp["Department"]; ?></td>
   	      <td><?php echo $att; ?></td>
   	      <td><?php echo timestamp($row["LastUpdate"]); ?></th>
   	    </tr>
   	     <?php
   	      	}
   	      } else {
   	      	EAS_ERRORS::JSAlert("No attendance history!");
   	      }
   	    ?>
   	  </tbody>
   	</table>
   </body>
 </html>
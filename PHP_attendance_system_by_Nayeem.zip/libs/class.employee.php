<?php
   /**
    * Simple class to select an employee from db
    * Copyright (c) 2017 EAS
    *
    * @package EAS
    */
   class EAS_EMPLOYEE {
   	public static function ID($empid) {
   		global $sql; //global var of mysqli class
   		$query = "SELECT * FROM employees WHERE id='{$empid}'";
   		$excution = $sql->query($query);
   		if(mysqli_num_rows($excution))
   		{
   			$row = mysqli_fetch_array($excution);
   			return $row;
   		} //endif
   	} //func ends
   } //class ends
?>
<?php
   /**
    * @configuration file management for attendance system
    *
    * @package EAS
    */
   class EAS_Config {
   	public function __construct($response) {
   		global $sql, $ini, $ini_path; //vars
   		$ini = "./@config/appconfig.ini";
   		$ini_path = $ini;
   		
   		return ($response);
   	} //func ends
   	
   	public static function setAppName($appname)
   	{
   		 if(ltrim($appname)  == null || ltrim($appname) == "default") {
   		 	  $appname = "Employee Attendance System";
   		 }
   		 $ini_r = @fopen("@config/appconfig.ini", "r")
   		 or      EAS_ERRORS::FatalError("We need the configuration file to complete the process! The configuration file has been deleted or moved parmanently! Please restore it!");
   		 $hexjson = @fread($ini_r, filesize("@config/appconfig.ini"));
   		
   		$object = @hex2bin($hexjson);
   		$config = json_decode($object);
   		@fclose($ini_r);
   		
   		
   		//write configuration 
   		$ini_w = fopen("@config/appconfig.ini", "w+") or EAS_ERRORS::FatalError("We need the configuration file to complete the process! The configuration file has been deleted or moved parmanently! Please restore it!");
   		$array = 
   		  array(
   		     "AppName" => $appname,
   		     "AppVersion" => $config->AppVersion,
   		     "Departments" => $config->Departments,
   		     "Address" => $config->Address,
   		     "Website" => $config->Website,
   		     "Phone" => $config->Phone,
   		     "Author" => $config->Author
   		  )
   		 ;
   		 $json = json_encode($array);
   		 $hexjson = bin2hex($json);
   		 if(fwrite($ini_w, $hexjson)) {
   		 	return true;
   		 } else {
   		 	return false;
   		 }
   		 fclose($ini_w);
   		 
   	} //func ends
   	
   	
   	
   	
   	public static function setDepartments($_array)
   	{
   		 $ini_r = @fopen("@config/appconfig.ini", "r")
   		 or      EAS_ERRORS::FatalError("We need the configuration file to complete the process! The configuration file has been deleted or moved parmanently! Please restore it!");
   		 $hexjson = @fread($ini_r, filesize("@config/appconfig.ini"));
   		
   		$object = @hex2bin($hexjson);
   		$config = json_decode($object);
   		@fclose($ini_r);
   		
   		
   		//write configuration 
   		$ini_w = fopen("@config/appconfig.ini", "w+") or EAS_ERRORS::FatalError("We need the configuration file to complete the process! The configuration file has been deleted or moved parmanently! Please restore it!");
   		
   		//create the array of departments
   		for($i=0; $i<=count($_array) - 1; $i++) {
   			$dep = ltrim($_array[$i]);
   			if($dep != null) {
   				$departments[] = $dep;
   			} //endif
   		}
   		
   		$array = 
   		  array(
   		     "AppName" => $config->AppName,
   		     "AppVersion" => $config->AppVersion,
   		     "Departments" => $departments,
   		     "Address" => $config->Address,
   		     "Website" => $config->Website,
   		     "Phone" => $config->Phone,
   		     "Author" => $config->Author
   		  )
   		 ;
   		 $json = json_encode($array);
   		 $hexjson = bin2hex($json);
   		 if(fwrite($ini_w, $hexjson)) {
   		 	return true;
   		 } else {
   		 	return false;
   		 }
   		 fclose($ini_w);
   		 
   	} //func ends
   	
   	
   	
   	
   	public static function setAddress($address)
   	{
   		 if(ltrim($address)  == null || ltrim($address) == "default") {
   		 	  $address = "Gouripur, Comilla";
   		 }
   		 $ini_r = @fopen("@config/appconfig.ini", "r")
   		 or      EAS_ERRORS::FatalError("We need the configuration file to complete the process! The configuration file has been deleted or moved parmanently! Please restore it!");
   		 $hexjson = @fread($ini_r, filesize("@config/appconfig.ini"));
   		
   		$object = @hex2bin($hexjson);
   		$config = json_decode($object);
   		@fclose($ini_r);
   		
   		
   		//write configuration 
   		$ini_w = fopen("@config/appconfig.ini", "w+") or EAS_ERRORS::FatalError("We need the configuration file to complete the process! The configuration file has been deleted or moved parmanently! Please restore it!");
   		$array = 
   		  array(
   		     "AppName" => $config->AppName,
   		     "AppVersion" => $config->AppVersion,
   		     "Departments" => $config->Departments,
   		     "Address" => $address,
   		     "Website" => $config->Website,
   		     "Phone" => $config->Phone,
   		     "Author" => $config->Author
   		  )
   		 ;
   		 $json = json_encode($array);
   		 $hexjson = bin2hex($json);
   		 if(fwrite($ini_w, $hexjson)) {
   		 	return true;
   		 } else {
   		 	return false;
   		 }
   		 fclose($ini_w);
   		 
   	} //func ends
   	
   	
   	
   	public static function setWebsite($web)
   	{
   		 if(ltrim($web)  == null || ltrim($web) == "default") {
   		 	  $web = "www.nayeem.cf";
   		 }
   		 $ini_r = @fopen("@config/appconfig.ini", "r")
   		 or      EAS_ERRORS::FatalError("We need the configuration file to complete the process! The configuration file has been deleted or moved parmanently! Please restore it!");
   		 $hexjson = @fread($ini_r, filesize("@config/appconfig.ini"));
   		
   		$object = @hex2bin($hexjson);
   		$config = json_decode($object);
   		@fclose($ini_r);
   		
   		
   		//write configuration 
   		$ini_w = fopen("@config/appconfig.ini", "w+") or EAS_ERRORS::FatalError("We need the configuration file to complete the process! The configuration file has been deleted or moved parmanently! Please restore it!");
   		$array = 
   		  array(
   		     "AppName" => $config->AppName,
   		     "AppVersion" => $config->AppVersion,
   		     "Departments" => $config->Departments,
   		     "Address" => $config->Address,
   		     "Website" => $web,
   		     "Phone" => $config->Phone,
   		     "Author" => $config->Author
   		  )
   		 ;
   		 $json = json_encode($array);
   		 $hexjson = bin2hex($json);
   		 if(fwrite($ini_w, $hexjson)) {
   		 	return true;
   		 } else {
   		 	return false;
   		 }
   		 fclose($ini_w);
   		 
   	} //func ends
   	
   	
   	
   	public static function setPhone($phone)
   	{
   		 if(ltrim($phone)  == null || ltrim($phone) == "default") {
   		 	  $phone = "+8801791241758";
   		 }
   		 $ini_r = @fopen("@config/appconfig.ini", "r")
   		 or      EAS_ERRORS::FatalError("We need the configuration file to complete the process! The configuration file has been deleted or moved parmanently! Please restore it!");
   		 $hexjson = @fread($ini_r, filesize("@config/appconfig.ini"));
   		
   		$object = @hex2bin($hexjson);
   		$config = json_decode($object);
   		@fclose($ini_r);
   		
   		
   		//write configuration 
   		$ini_w = fopen("@config/appconfig.ini", "w+") or EAS_ERRORS::FatalError("We need the configuration file to complete the process! The configuration file has been deleted or moved parmanently! Please restore it!");
   		$array = 
   		  array(
   		     "AppName" => $config->AppName,
   		     "AppVersion" => $config->AppVersion,
   		     "Departments" => $config->Departments,
   		     "Address" => $config->Address,
   		     "Website" => $config->Website,
   		     "Phone" => $phone,
   		     "Author" => $config->Author
   		  )
   		 ;
   		 $json = json_encode($array);
   		 $hexjson = bin2hex($json);
   		 if(fwrite($ini_w, $hexjson)) {
   		 	return true;
   		 } else {
   		 	return false;
   		 }
   		 fclose($ini_w);
   		 
   	} //func ends

   	
   	
   	
   	
   	
   	public static function getAppName() {
   		 $ini_r = @fopen("@config/appconfig.ini", "r") or EAS_ERRORS::FatalError("We need the configuration file to complete the process! The configuration file has been deleted or moved parmanently! Please restore it!");
   		 $hexjson = fread($ini_r, filesize("@config/appconfig.ini")) or ESA_ERRORS::FatalError("The configuration file is invalid or has been expired! Please reinstall it!");
   		
   		$object = hex2bin($hexjson);
   		$config = json_decode($object);
   		fclose($ini_r);
   		return $config->AppName;
   	}
   	
   	public static function getAppVersion() {
   		 $ini_r = fopen("@config/appconfig.ini", "r") or EAS_ERRORS::FatalError("We need the configuration file to complete the process! The configuration file has been deleted or moved parmanently! Please restore it!");
   		 $hexjson = fread($ini_r, filesize("@config/appconfig.ini"));
   		
   		$object = hex2bin($hexjson);
   		$config = json_decode($object);
   		fclose($ini_r);
   		return $config->AppVersion;
   	} //func ends
   	
   	
   	
   	public static function getDepartments() {
   		 $ini_r = fopen("@config/appconfig.ini", "r") or EAS_ERRORS::FatalError("We need the configuration file to complete the process! The configuration file has been deleted or moved parmanently! Please restore it!");
   		 $hexjson = fread($ini_r, filesize("@config/appconfig.ini"));
   		
   		$object = hex2bin($hexjson);
   		$config = json_decode($object);
   		fclose($ini_r);
   		
   		//return departments array
   		$deps = $config->Departments;
   		if(count($deps) == 0) {
   			return 0;
   		} else {
   			return $deps;
   		}
   	} //func ends
   	
   	
   	
   	
   	public static function getAddress() {
   		 $ini_r = @fopen("@config/appconfig.ini", "r") or EAS_ERRORS::FatalError("We need the configuration file to complete the process! The configuration file has been deleted or moved parmanently! Please restore it!");
   		 $hexjson = fread($ini_r, filesize("@config/appconfig.ini")) or ESA_ERRORS::FatalError("The configuration file is invalid or has been expired! Please reinstall it!");
   		
   		$object = hex2bin($hexjson);
   		$config = json_decode($object);
   		fclose($ini_r);
   		return $config->Address;
   	}
   	
   	
   	public static function getWebsite() {
   		 $ini_r = @fopen("@config/appconfig.ini", "r") or EAS_ERRORS::FatalError("We need the configuration file to complete the process! The configuration file has been deleted or moved parmanently! Please restore it!");
   		 $hexjson = fread($ini_r, filesize("@config/appconfig.ini")) or ESA_ERRORS::FatalError("The configuration file is invalid or has been expired! Please reinstall it!");
   		
   		$object = hex2bin($hexjson);
   		$config = json_decode($object);
   		fclose($ini_r);
   		return $config->Website;
   	}
   	
   	
   	public static function getPhone() {
   		 $ini_r = @fopen("@config/appconfig.ini", "r") or EAS_ERRORS::FatalError("We need the configuration file to complete the process! The configuration file has been deleted or moved parmanently! Please restore it!");
   		 $hexjson = fread($ini_r, filesize("@config/appconfig.ini")) or ESA_ERRORS::FatalError("The configuration file is invalid or has been expired! Please reinstall it!");
   		
   		$object = hex2bin($hexjson);
   		$config = json_decode($object);
   		fclose($ini_r);
   		return $config->Phone;
   	}
   	
   	
   	public static function getAuthor() {
   		 $ini_r = @fopen("@config/appconfig.ini", "r") or EAS_ERRORS::FatalError("We need the configuration file to complete the process! The configuration file has been deleted or moved parmanently! Please restore it!");
   		 $hexjson = fread($ini_r, filesize("@config/appconfig.ini")) or ESA_ERRORS::FatalError("The configuration file is invalid or has been expired! Please reinstall it!");
   		
   		$object = hex2bin($hexjson);
   		$config = json_decode($object);
   		fclose($ini_r);
   		return $config->Author;
   	}
   	
   } //ends class
?>
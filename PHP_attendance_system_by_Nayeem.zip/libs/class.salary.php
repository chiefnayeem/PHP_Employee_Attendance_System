<?php
   /**
    * Simple class for counting the salaries of the employers
    *
    * @package EAS
    */
   class EAS_SALARY {
   	public static function CountByHours($fixed_salary, $hrs)
   	{
   		global $sql;
   		$full_day_salary = $fixed_salary/26;
   		$each_hour_salary = $full_day_salary/8;
   		
   		return $each_hour_salary*$hrs;
   	} //func ends
   	
   	public static function AttendanceAndSalaryInfo($empid, $month, $year)
   	{
   		global $sql;
   		$emp = EAS_EMPLOYEE::ID($empid);
   		$query = "SELECT * FROM attendance WHERE EMP_ID='{$empid}' AND Month='{$month}' AND Year='{$year}'";
   		$excution = $sql->query($query);
   		
   		if(mysqli_num_rows($excution)) {
   			$day_ = 0; //day counter
   			$total_salary = 0; //salary counter
   			while($row = mysqli_fetch_object($excution))
   			{
   				$day_ = $day_ + 1;
   				$hrs = CountHours($row->Attendance);
   				$fixed_salary = $emp["Salary"];
   				$full_day_salary = $fixed_salary/26;
   				$each_hour_salary = $full_day_salary/8;
   				$salary = $each_hour_salary*$hrs;
   				
   				$total_salary = $total_salary + $salary;
   			} //ends while
   			
   			if($day_ == 1) {
   				$day_= $day_." day";
   			} elseif($day_ > 1) {
   				$day_ = $day_." days";
   			}
   			$array =
   			array(
   			    "WORKED" => $day_,
   			    "TOTAL_SALARY" => $total_salary
   			);
   			return $array;
   		} else {
   			$array =
   			array(
   			   "WORKED" => "0 day",
   			   "TOTAL_SALARY" => "0",
   			   "MESSAGE" => "No attendance"
   			);
   			return $array;
   		}
   	} //func ends
   } //class ends
?>
<?php
   //class for login, only for admins
   class login {
   	/**
   	 * @override class constructor
   	 */
   	public function __construct($email, $pass)
   	{
   		global $sql; //global var
   		
   		//queries to validate the user
   		$queryE = "SELECT * FROM users WHERE Email='$email'";
   		
   		IF(mysqli_num_rows($sql->query($queryE))) {
   			//correct email
   			
   			$queryP = "SELECT * FROM users WHERE Email='$email' AND Password='$pass'";
   			
   			if(mysqli_num_rows($sql->query($queryP))) {
   				//password is correct
   				//logged in
   				$_SESSION["Email"] = $email; //logged in
   				header("Location: dashboard.php?sess_=logged_in&__");
   			} else {
   				//incorrect password
   				print '
   				    $(document).ready(function(){
   				    	Materialize.toast("Your password was incorrect!", 4000);
   				    });
   				';
   				
   			}
   		} else {
   			//incorrect email
   			print '
   				    $(document).ready(function(){
   				    	Materialize.toast("The email you entered was not found!", 4000);
   				    });
   				';
   		}
   	} //ends function
   } //ends class
?>
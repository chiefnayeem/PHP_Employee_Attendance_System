<?php
   /**
    * Php class to show errors if occured
    * only for Employee Attendance System
    *
    * @package EAS
    */
   class EAS_ERRORS {
   	/**
   	 * @Fatal error function, can be called statically
   	 */
   	public static function FatalError($err_msg)
   	{
   		$html = '<html lang="en">';
   		$html .= '<head>';
   		$html .= '<title>Fatal Error - EAS</title>';
   		$html .= '<style>';
   		$html .= '*{font-family: arial;} body {margin: 0; padding: 0; background: #dddddd;} .errbody{margin: 20%;} .header {padding: 20px; display: block; margin: 0; background: #e53935; color: #ffffff; font-weight: bold;} .container {display: block; margin: 0; padding: 20px; background: white; color: black; border: 1px solid #a6a6a6; border-top: 0;}';
   		$html .= '</style>';
   		$html .= '</head>';
   		$html .= '<body>';
   		$html .= '<div class="errbody">';
   		$html .= '<div class="header">Fatal Error</div>';
   		$html .= '<div class="container">';
   		$html .= $err_msg;
   		$html .= '</div>';
   		$html .= '</div>';
   		$html .= '</body>';
   		$html .= '</html>';
   		
   		$__html__ = $html;
   		die($__html__);
   	} //func ends
   	
   	/**
   	 * @Warning error
   	 */
   	public static function Warning($err_msg)
   	{
   		$html = '<html lang="en">';
   		$html .= '<head>';
   		$html .= '<title>Warning - EAS</title>';
   		$html .= '<style>';
   		$html .= '*{font-family: arial;} body {margin: 0; padding: 0; background: #dddddd;} .errbody{margin: 20%;} .header {padding: 20px; display: block; margin: 0; background: #e53935; color: #ffffff; font-weight: bold;} .container {display: block; margin: 0; padding: 20px; background: white; color: black; border: 1px solid #a6a6a6; border-top: 0;}';
   		$html .= '</style>';
   		$html .= '</head>';
   		$html .= '<body>';
   		$html .= '<div class="errbody">';
   		$html .= '<div class="header">Warning</div>';
   		$html .= '<div class="container">';
   		$html .= $err_msg;
   		$html .= '</div>';
   		$html .= '</div>';
   		$html .= '</body>';
   		$html .= '</html>';
   		
   		$__html__ = $html;
   		die($__html__);
   	} //func ends
   	
   	public static function JSAlert($msg)
   	{
   		echo '<script>alert("'.$msg.'");</script>';
   	} //func ends
   } //class ends
?>
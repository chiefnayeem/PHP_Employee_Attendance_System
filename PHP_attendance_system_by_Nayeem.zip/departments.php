<?php
 /**
  * Departments, List of all Employees in a table to be printed
  *
  * @package EAS
  */
 require './@config/config.php';
 require './@config/db.config.php';
 require './libs/class.error.php';
 require './libs/class.config.php';
 require './libs/class.employee.php';
?><!DOCTYPE html>
<html lang="en">
   <head>
      <title>Departments</title>
      <meta charset="utf-8">
      <!--<meta name="viewport" content="initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no"> -->
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="msapplication-tap-highlight" content="no">
      <meta name="theme-color" content="#607d8b">
      <link rel="STYLESHEET" href="./res/css/materialize.min.css"/>
      <link rel="STYLESHEET" href="./res/css/font-awesome.min.css" />
      <script src="./res/js/jquery.min.js"></script>
      <script src="./res/js/materialize.min.js"></script>
      <script>
      	function goBack() {
      		window.history.back();
      	}
      </script>
      <style>
       th, td {
       	text-align: left;
       	padding-left: 50px;
       }
      </style>
   </head>
   <body>
      <div class="row white" style="border-bottom: 1px solid #a6a6a6; margin: 0;">
   		<div class="col s6" style="text-align: left; padding: 0;">
   			<b style="padding: 10px; display: block;">Departments (<?php echo count(EAS_CONFIG::getDepartments()); ?> departments)</b>
   		</div>
   	</div>
   	
   	<table class="bordered striped" style="width: 100%;">
   	  <thead>
   	    <tr>
   	      <th>Department Name</th>
   	      <th>Employees</th>
   	    </tr>
   	  </thead>
   	  <tbody>
   	  <?php
   	  foreach(EAS_CONFIG::getDepartments() as $dep)
   	  {
   	  	  $emp_s = mysqli_num_rows($sql->query("SELECT * FROM employees WHERE Department='{$dep}'"));
   	  	  $emps = $emp_s." employees";
   	  	  
   	  	  switch($emp_s) {
   	  	  	  case 1:
   	  	  	    $emps = "1 employee";
   	  	  	    break;
   	  	  	  case 0:
   	  	  	    $emps = "No employees";
   	  	  	    break;
   	  	  }
   	  ?>
   	    <tr onclick='location="department.php?dep_=<?php echo $dep; ?>"; '>
   	      <td><?php echo $dep; ?></td>
   	      <td><?php echo  $emps; ?></td>
   	    </tr>
   	  <?php
   	  }
   	  ?>
   	  </tbody>
   	</table>
   </body>
 </html>

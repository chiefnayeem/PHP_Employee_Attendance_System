<?php
 /**
  * Settings, Writing  & changing configuration file
  *
  * @package EAS
  */
 require './@config/config.php';
 require './@config/db.config.php';
 require './libs/class.error.php';
 require './libs/class.config.php';
 
 

 if(isset($_GET["query"])) {
 	$query = $_GET["query"];
 	
 	/**
 	 * @appname settings
 	 */
 	if($query == "appname") {
 		if(isset($_POST["appname"]))
 		{
 			$appname = $_POST["appname"];
 			if(EAS_Config::setAppName($appname))
 			{
 				EAS_ERRORS::JSAlert("Business name updated! Please refresh the page!");
 			}
 		}
 	} elseif ($query == "appname_default") {
 		if(EAS_Config::setAppName("default"))
 			{
 				EAS_ERRORS::JSAlert("Business name changed to default! Please refresh the page!");
 			}
 	}
 	
 	
 	
 	/**
 	 * @address settings
 	 */
 	if($query == "address") {
 		if(isset($_POST["address"]))
 		{
 			$address = $_POST["address"];
 			if(EAS_Config::setAddress($address))
 			{
 				EAS_ERRORS::JSAlert("Address updated! Please refresh the page!");
 			}
 		}
 	} elseif ($query == "address_default") {
 		if(EAS_Config::setAddress("default"))
 			{
 				EAS_ERRORS::JSAlert("Address changed to default! Please refresh the page!");
 			}
 	}
 	
 	
 	/**
 	 * @website settings
 	 */
 	if($query == "website") {
 		if(isset($_POST["website"]))
 		{
 			$website = $_POST["website"];
 			if(EAS_Config::setWebsite($website))
 			{
 				EAS_ERRORS::JSAlert("Website updated! Please refresh the page!");
 			}
 		}
 	} elseif ($query == "website_default") {
 		if(EAS_Config::setWebsite("default"))
 			{
 				EAS_ERRORS::JSAlert("Website changed to default! Please refresh the page!");
 			}
 	}
 	
 	
 	
 	/**
 	 * @phone settings
 	 */
 	if($query == "phone") {
 		if(isset($_POST["phone"]))
 		{
 			$phone = $_POST["phone"];
 			if(EAS_Config::setPhone($phone))
 			{
 				EAS_ERRORS::JSAlert("Phone number updated! Please refresh the page!");
 			}
 		}
 	} elseif ($query == "phone_default") {
 		if(EAS_Config::setPhone("default"))
 			{
 				EAS_ERRORS::JSAlert("Phone number changed to default! Please refresh the page!");
 			}
 	}
 	
 	
 	/**
 	 * @departments settings
 	 */
 	if($query == "departments") {
 		if(isset($_POST["departments"]))
 		{
 			$dep = $_POST["departments"];
 			if(EAS_Config::setDepartments($dep))
 			{
 				EAS_ERRORS::JSAlert("Departments added!");
 				header("Location: ?");
 			}
 		}
 	}
 	
 	
 } //endif
?><!DOCTYPE html>
<html lang="en">
   <head>
      <title>Settings</title>
      <meta charset="utf-8">
      <!--<meta name="viewport" content="initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no"> -->
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="msapplication-tap-highlight" content="no">
      <meta name="theme-color" content="#607d8b">
      <link rel="STYLESHEET" href="./res/css/materialize.min.css"/>
      <link rel="STYLESHEET" href="./res/css/font-awesome.min.css" />
      <script src="./res/js/jquery.min.js"></script>
      <script src="./res/js/materialize.min.js"></script>
      <script>
      	function goBack() {
      		window.history.back();
      	}
      	
      	
      	function submitForm( form_id )
{
    var form = document.getElementById( form_id );
    var form_elements = document.getElementsByClassName( form_id );
    var i;
    for (i = 0; i < form_elements.length; i++) {
        form.appendChild( form_elements[i] );                   
    }
    form.submit();
}   
      </script>
      <style>
       th, td {
       	text-align: left;
       	padding-left: 50px;
       }
       input[type=submit] {
       	    padding: 8px 10px;
            border-radius: 2px;
            border: 0;
       }
      </style>
   </head>
   <body>
      <div class="row white" style="border-bottom: 1px solid #a6a6a6; margin: 0;">
   		<div class="col s6" style="text-align: left; padding: 0;">
   			<b style="padding: 10px; display: block;">App Settings</b>
   		</div>
   	</div>
   	
   	<div style="margin: 20%; margin-top: 0;">
   	  <table class="bordered" style="width: 100%; border: 1px solid #a6a6a6;">
   	    <!-- App name -->
   	    <tr>
   	      <th>App name</th>
   	      <th>Action</th>
   	    </tr>
   	    <form id="appname" method="POST" action="?query=appname">
   	    <tr>
   	      <td>
   	        <input type="text" placeholder="Enter Business name" value="<?php echo EAS_Config::getAppName(); ?>" name="appname" class="appname"/>
   	      </td>
   	      <td>
   	        <input class="teal white-text waves-effect waves-light" type="submit" value="Save" name="save_appname" onclick='submitForm("appname");'/>
   	        <a href="?query=appname_default"><input class="teal white-text waves-effect waves-light" type="submit" value="Default" name="default_appname" /></a>
   	      </td>
   	    </tr>
   	  </form>
   	  
   	  
   	    <!-- Address -->
   	    <tr>
   	      <th>Address</th>
   	      <th>Action</th>
   	    </tr>
   	    
   	    <form id="address" method="POST" action="?query=address">
   	    <tr>
   	      <td>
   	        <input type="text" placeholder="Enter address" value="<?php echo EAS_Config::getAddress(); ?>" name="address" class="address"/>
   	      </td>
   	      <td>
   	        <input class="teal white-text waves-effect waves-light" type="submit" value="Save" onclick="submitForm('address');" />
   	        <a href="?query=address_default"><input class="teal white-text waves-effect waves-light" type="submit" value="Default" name="default" /></a>
   	      </td>
   	    </tr>
   	    </form>
   	    
   	    
   	    
   	    
   	    <!-- Website -->
   	    <tr>
   	      <th>Website</th>
   	      <th>Action</th>
   	    </tr>
   	    <form id="website" method="POST" action="?query=website">
   	    <tr>
   	      <td>
   	        <input type="text" placeholder="Enter business website" value="<?php echo EAS_Config::getWebsite(); ?>" name="website" class="website"/>
   	      </td>
   	      <td>
   	        <input class="teal white-text waves-effect waves-light" type="submit" value="Save" onclick="submitForm('website');" />
   	        <a href="?query=website_default"><input class="teal white-text waves-effect waves-light" type="submit" value="Default" /></a>
   	      </td>
   	    </tr>
   	    </form>
   	    
   	    
   	    <!-- Phone -->
   	    <tr>
   	      <th>Phone number</th>
   	      <th>Action</th>
   	    </tr>
   	    <form id="number" method="POST" action="?query=phone">
   	    <tr>
   	      <td>
   	        <input type="text" placeholder="Enter contact number" value="<?php echo EAS_CONFIG::getPhone(); ?>" name="phone" class="number" />
   	      </td>
   	      <td>
   	        <input class="teal white-text waves-effect waves-light" type="submit" value="Save" onclick="submitForm('number');" />
   	        <a href="?query=phone_default"><input class="teal white-text waves-effect waves-light" type="submit" value="Default"/></a>
   	      </td>
   	    </tr>
   	    </form>
   	    
   	    
   	    
   	    <!-- Employee Departments -->
   	    <form id="department" method="POST" action="?query=departments">
   	    <tr>
   	      <th colspan="2" id="add_department">Employee Departments</th>
   	    </tr>
   	    
   	    <tr>
   	      <td colspan="2">
   	        <b>Caution</b>: By changing or deleting a department may lose it&#39;s employee details
   	        <departments>
   	        <?php
   	        foreach(EAS_Config::getDepartments() as $dep)
   	        {
   	        	?>
   	        	  <input type="text" placeholder="Enter department" name="departments[]" class="department" value="<?php echo $dep; ?>"/>
   	        	<?php
   	        }
   	        ?>
   	        </departments>
   	       <a class="teal-text" role="add_dep_input">Add more</a>
   	      </td>
   	    </tr>
   	    <tr>
   	      <td colspan="2">
   	        <input class="teal white-text waves-effect waves-light" type="submit" value="Save" onclick="submitForm('department');"/>
   	      </td>
   	    </tr>
   	    </form>
   	    
   	    
   	    <!-- App version -->
   	    <tr>
   	      <th colspan="2">App version</th>
   	    </tr>
   	    
   	    <tr>
   	      <td colspan="2">
   	        <input type="text" placeholder="" value="<?php echo EAS_Config::getAppVersion(); ?>" disabled/>
   	      </td>
   	    </tr>
   	    
   	    
   	    <!-- App author -->
   	    <tr>
   	      <th colspan="2">App author</th>
   	    </tr>
   	    
   	    <tr>
   	      <td colspan="2">
   	        <input type="text" placeholder="" value="<?php echo EAS_Config::getAuthor(); ?>" disabled/>
   	      </td>
   	    </tr>
   	</table>
   	</div>
   	
   	<script>
   	  $(document).ready(function(){
   	  	 $("[role=add_dep_input]").click(function(){
   	  	 	$("departments").append('<input type="text" placeholder="Enter department" name="departments[]" class="department"/>');
   	  	 });
   	  });
   	</script>
   </body>
 </html>
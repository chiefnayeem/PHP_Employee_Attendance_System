<?php
 /**
  * @employee edition, using html form
  *
  * @package EAS
  */
 require './@config/config.php';
 require './libs/class.error.php';
 require './libs/class.config.php';
 require './libs/class.employee.php';
 
 $empid = $_GET["empid"];
 $emp = EAS_EMPLOYEE::ID($empid);
 
 if(isset($_POST["edit_emp"]))
 {
 	 $data = $_POST; //array var
 	 $fname = ltrim($data["fname"]);
 	 $lname = ltrim($data["lname"]);
 	 $fullname = $fname." ".$lname;
 	 $age = ltrim($data["age"]);
 	 $mobile = ltrim($data["mobile"]);
 	 $email = ltrim($data["email"]);
 	 $blood = ltrim($data["blood"]);
 	 $address = addslashes(ltrim($data["address"]));
 	 $department = ltrim($data["department"]);
 	 $salary = ltrim($data["salary"]);
 	 
 	 
 	 	$now = time();
 	 	$query = "UPDATE employees SET FirstName='{$fname}', LastName='{$lname}', FullName='{$fullname}', Age='{$age}', BloodGroup='{$blood}', Address='{$address}', Phone='{$mobile}', Department='{$department}', Salary='{$salary}', Email='{$email}' WHERE id='{$empid}'";
 	 	
 	 	if($sql->query($query)) {
 	 		EAS_ERRORS::JSAlert("Employee's info updated successfully!");
 	 	} else {
 	 		EAS_ERRORS::Warning(mysqli_error($sql));
 	 	}
 	
 } //end if
?><!DOCTYPE html>
<html lang="en">
   <head>
      <meta charset="utf-8">
      <meta name="viewport" content="initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no"> 
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="msapplication-tap-highlight" content="no">
      <meta name="theme-color" content="#607d8b">
      <link rel="STYLESHEET" href="./res/css/materialize.min.css"/>
      <link rel="STYLESHEET" href="./res/css/font-awesome.min.css" />
      <script src="./res/js/jquery.min.js"></script>
      <script src="./res/js/materialize.min.js"></script>
      <script>
         $(document).ready(function() {
            Materialize.updateTextFields();
            $('select').material_select();
            $('.modal').modal();
         });
         
         function goBack() {
      		window.history.back();
      	}
         /**
          * modal alert
          */
         function malert($title, $msg) {
            	$(document).ready(function(){
            		$('#modal').modal('open');
            		$('.modal [contain=title]').text($title);
            		$('.modal [contain=msg]').text($msg);
            	});
         }
         
         function validateEditForm() {
            var fname = document.forms["RegisterEmployee"]["fname"].value,
                    lname = document.forms["RegisterEmployee"]["lname"].value,
                    age = document.forms["RegisterEmployee"]["age"].value,
                    mobile = document.forms["RegisterEmployee"]["mobile"].value,
                    email = document.forms["RegisterEmployee"]["email"].value,
                    blood = document.forms["RegisterEmployee"]["blood"].value,
                    department = document.forms["RegisterEmployee"]["department"].value,
                    address = document.forms["RegisterEmployee"]["address"].value,
                    salary = document.forms["RegisterEmployee"]["salary"].value;

            if(fname.trim() == "") {
               malert("Form validation", "First name is required! ");
               document.getElementById("first_name").style = "border-bottom: 2px solid red;";
               return false;
            } else {
               document.getElementById("first_name").style = "border-bottom: 1px solid #2e7d32;";
            }
            if(lname.trim() == "") {
               malert("Form validation", " Last name is required! ");
               document.getElementById("last_name").style = "border-bottom: 2px solid red;";
               return false;
            } else {
               document.getElementById("last_name").style = "border-bottom: 1px solid #2e7d32;";
            }
            
            if(age.trim() == "") {
               malert("Form validation", "Enter the age of this employee!");
               document.getElementById("age").style = "border-bottom: 2px solid red;";
               return false;
            } else {
               document.getElementById("age").style = "border-bottom: 1px solid #2e7d32;";
            }
            
            
            
            if(mobile.trim() == "") {
               malert("Form validation", " Mobile number is required! ");
               document.getElementById("number").style = "border-bottom: 2px solid red;";
               return false;
            } else {
               document.getElementById("number").style = "border-bottom: 1px solid #2e7d32;";
            }
            if(email.trim() == "") {
               malert("Form validation", " Email is required! ");
               document.getElementById("email").style = "border-bottom: 2px solid red;";
               return false;
            } else {
               document.getElementById("email").style = "border-bottom: 1px solid #2e7d32;";
            }
            if(blood.trim() == "") {
               malert("Form validation", " Select a blood group! ");
               document.getElementById("blood").style = "border-bottom: 2px solid red;";
               return false;
            } else {
               document.getElementById("blood").style = "border-bottom: 1px solid #2e7d32;";
            }
            if(department.trim() == "") {
               malert("Form validation", " Select a department! ");
               document.getElementById("department").style = "border-bottom: 2px solid red;";
               return false;
            } else {
               document.getElementById("department").style = "border-bottom: 1px solid #2e7d32;";
            }
            if(address.trim() == "") {
               malert("Form validation", "Employee's address is required! ");
               document.getElementById("address").style = "border-bottom: 2px solid red;";
               return false;
            } else {
               document.getElementById("address").style = "border-bottom: 1px solid #2e7d32;";
            }
            if(salary.trim() == "") {
               malert("Form validation", "Enter the salary of this employee");
               document.getElementById("salary").style = "border-bottom: 2px solid red;";
               return false;
            } else {
               document.getElementById("salary").style = "border-bottom: 1px solid #2e7d32;";
            }
         }
      </script>
      <style>
      	h4 {color: grey;}
      </style>
   </head>
   <body>
      <div class="row white" style="border-bottom: 1px solid #a6a6a6; margin: 0;">
   		<div class="col s6" style="text-align: left; padding: 0;">
   			<b class="waves-effect waves-default fa fa-arrow-left" onclick='goBack();' style="padding: 11px;">&nbsp; Back to the employee profile</b>
   		</div>
   	</div>
   	
      <div class="row">
         <div class="col s12 m5" style="width: 89%; margin: 60px; margin-top: 10px;">
            <fieldset class="card-panel white" style="color: black;">
            	<legend><h4>Edit Employee</h4></legend>

               <!-- edit employee, forms -->
               <div class="row">
                  <form class="col s12" name="RegisterEmployee" onSubmit="return validateEditForm();" method="POST">
                     <div class="row">
                        <div class="input-field col s6">
                           <input id="first_name" type="text" class="validate" name="fname" value="<?php echo $emp['FirstName']; ?>">
                           <label for="first_name">First Name</label>
                        </div>
                        <div class="input-field col s6">
                           <input id="last_name" type="text" class="validate" name="lname" value="<?php echo $emp['LastName']; ?>">
                           <label for="last_name">Last Name</label>
                        </div>
                     </div>
                     
                     <!-- Age -->
                     <div class="row">
                        <div class="input-field col s12">
                           <input id="age" type="number" class="validate" name="age" value="<?php echo $emp['Age']; ?>">
                           <label for="age">Age</label>
                        </div>
                     </div>
                     
                     <div class="row">
                        <div class="input-field col s12">
                           <input id="number" type="number" class="validate" name="mobile" value="<?php echo $emp['Phone']; ?>">
                           <label for="number">Mobile number</label>
                        </div>
                     </div>
                     <div class="row">
                        <div class="input-field col s12">
                           <input id="email" type="email" class="validate" name="email" value="<?php echo $emp['Email']; ?>">
                           <label for="email">Email</label>
                        </div>
                     </div>

                     <!-- Blood group -->
                     <div class="input-field col s12">
                        <select name="blood" id="blood" class="browser-default">
                        <?php
                          $bg = $emp["BloodGroup"];
                        ?>
                           <option value="" disabled <?php if($bg == null) { echo "selected"; }?>>Select blood group</option>
                           <option value="A+" <?php if($bg == "A+") { echo "selected"; } ?>>A +</option>
                           <option value="A-" <?php if($bg == "A-") { echo "selected"; } ?>>A -</option>
                           <option value="B+" <?php if($bg == "B+") { echo "selected"; } ?>>B +</option>
                           <option value="AB+" <?php if($bg == "AB+") { echo "selected"; } ?>>AB +</option>
                           <option value="AB-" <?php if($bg == "AB-") { echo "selected"; } ?>>AB -</option>
                           <option value="O+" <?php if($bg == "O+") { echo "selected"; } ?>>O +</option>
                           <option value="O-" <?php if($bg == "O-") { echo "selected"; } ?>>O -</option>
                        </select>
                        <label>Blood group</label>
                     </div>
                     
                     <!-- Department -->
                     <div class="input-field col s12">
                        <select name="department" id="department" class="browser-default">
                        <?php
                         $deps = EAS_CONFIG::getDepartments();
                        ?>
                           <option value="" disabled <?php if($deps == 0) { echo "selected"; } ?>>Select department</option>
                           <?php
                           $emp_dep = $emp["Department"];
                            foreach($deps as $dep) {
                            	if($dep == $emp_dep) {
                            		$selection = "selected";
                            	} else {
                            		$selection = null;
                            	}
                            	 echo '<option value="'.$dep.'" '.$selection.'>'.$dep.'</option>'."\n";
                            }
                           ?>
                        </select>
                        <label>Depaertment</label>
                     </div>

                     <!-- Address -->
                     <div class="row">
                        <div class="row">
                           <div class="input-field col s12">
                              <textarea id="address" class="materialize-textarea" name="address"><?php echo $emp['Address']; ?></textarea>
                              <label for="address">Address</label>
                           </div>
                        </div>
                     </div>
                     
                     <!-- Salary -->
                     <div class="row">
                        <div class="input-field col s12">
                           <input id="salary" type="number" class="validate" name="salary" value="<?php echo $emp['Salary']; ?>">
                           <label for="salary">Salary</label>
                        </div>
                     </div>
                     
                     <input type="submit" class="waves-effect waves-light btn" value="Save changes" name="edit_emp" />
                  </form>
               </div>
               <!-- Input types ends -->


            </fieldset>
         </div>
      </div>
      
      
      <!-- Modal  -->
      <div id="modal" class="modal">
      	<div class="modal-content">
      		<h4 contain="title"></h4>
      		<p contain="msg"></p>
      	</div>
      	<div class="modal-footer">
      		<a href="#!" class=" modal-action modal-close waves-effect waves-teal btn-flat">Ok</a>
      	</div>
      </div>
      <!-- Modal ends -->
   </body>
</html>
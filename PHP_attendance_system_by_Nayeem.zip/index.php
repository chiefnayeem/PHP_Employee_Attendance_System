<?php
  /**
   * attendance system
   */
   session_start();
   require './libs/class.error.php';
   require './@config/config.php';
   require './libs/class.login.php';
   require './libs/class.config.php';
   
   if(isset($_SESSION["Email"])) {
   	$_email = $_SESSION["Email"];
   	header("Location: dashboard.php?referer_=index&root_=ini.host&__");
   } else {
   	//login to continue
?><!DOCTYPE html>
<html lang="en">
   <head>
      <title><?php echo EAS_Config::getAppName(); ?></title>
      <meta charset="utf-8">
      <!-- <meta name="viewport" content="initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no"> 
      <meta http-equiv="X-UA-Compatible" content="IE=edge"> -->
      <meta name="msapplication-tap-highlight" content="no">
      <meta name="theme-color" content="#607d8b">
      <link rel="STYLESHEET" href="./res/css/materialize.min.css"/>
      <link rel="STYLESHEET" href="./res/css/icons.css" />
      <link rel="STYLESHEET" href="./res/css/font-awesome.min.css" />
      <script src="./res/js/jquery.min.js"></script>
      <script src="./res/js/materialize.min.js"></script>
      <script src="./res/js/framework.js"></script>
      <style>
         a.brand-logo {
            font-size: 30px;
			 margin-left: 25px;
         }
         nav { height: 80px;}
         nav .nav-wrapper {
         	padding: 8px;
         }
         fieldset.form-container {
         	margin-top: 5%;
         	margin-left: 30%;
         	margin-right: 30%;
         	padding: 10px;
			 border-radius: 2px;
         }
         fieldset.form-container legend {
         	margin-left: 20px;
         }
         h5 {color: grey; }
      </style>
      <script>
   	<?php
   	    if(isset($_POST["login"])) {
   	    	 $email = ltrim($_POST["email"]);
   	    	 $pass = ltrim($_POST["password"]);
   	    	 $cookie = ltrim($_POST["cookie"]);
   	    	 
   	    	 if($email != null && $pass != null) {
   	    	 	 //login an user
   	    	 	 new login($email, $pass);
   	    	 	 //set a cookie to remember info
   	    	 	 if(isset($_POST["cookie"]) && $_POST["cookie"] != null) {
   	    	 	 	$cookie_life = 2000000000;
   	    	 	 	setcookie('Email', $emaip, $cookie_life);
   	    	 	 	setcookie('Password', $pass, $cookie_life);
   	    	 	 }
   	    	 }
   	    }
   	?>
   	function validateLoginForm() {
   		var email = document.forms["LoginForm"]["email"].value;
   		       pass = document.forms["LoginForm"]["password"].value;
   		       if(email.trim() == "") {
   		       	alert("Please enter your email!");
   		       	document.getElementById("email").style = "border-bottom: 2px solid red;";
   		       	return false; 
               } else {
               	document.getElementById("email").style = "border-bottom: 1px solid #2e7d32;";
               }
               
               if(pass == "") {
   		       	alert("Please enter your password!");
   		       	document.getElementById("password").style = "border-bottom: 2px solid red;";
   		       	return false;
               } else {
               	document.getElementById("password").style = "border-bottom: 1px solid #2e7d32;";
               }
               
         } //function ends
   	</script>
   </head>
   <body>
   	<!-- Header -->
   	<nav class="teal">
   		<div class="nav-wrapper">
   			<a href="#" class="brand-logo"><?php echo EAS_Config::getAppName(); ?></a>
   		</div>
   	</nav>
   	<!-- header ends -->
     
   	
   	<!-- login form container -->
   	<fieldset class="form-container z-depth-1">
   		<legend><h5>LOGIN</h5></legend>
   		<!-- form starts -->
   		<div class="row">
   			<form name="LoginForm" class="col s12" action="?referer_=this&query=login" method="POST" onsubmit="return validateLoginForm();">
   				<!-- Email input -->
   				<div class="row">
   					<div class="input-field col s12">
   						<input id="email" type="email" class="validate" name="email" <?php if(isset($_COOKIE['Email'])) { echo 'value="'.$_COOKIE['Email'].'"'; } ?> />
   						<label for="email" data-error="wrong" data-success="right">Email</label>
   					</div>
   					
   					<!-- Password input -->
   					<div class="row">
   					<div class="input-field col s12">
   						<input id="password" type="password" class="validate" name="password" <?php if(isset($_COOKIE['Password'])) { echo 'value="'.$_COOKIE['Password'].'"'; } ?> />
   						<label for="password" data-error="wrong" data-success="right">Password</label>
   					</div>
   				</div>
   				
   				<div class="row">
   					<div class="col s12">
   						<input type="checkbox" class="filled-in" id="filled-in-box" name="cookie" />
   						<label for="filled-in-box">Remember me</label>
   					</div>
   				</div>
   				
   				<!-- Submit button -->
   				<div style="text-align: center;">
   					<button type="submit" class="btn-floating btn-large waves-effect waves-light teal center" name="login">GO</button>
   				</div>
    
   			</form>
   		</div>
   		<!-- form ends -->
   	</fieldset>
   </body>
</html><?php
  }
?>
<?php
 /**
  * @employee delete, if ajax requests
  *
  * @package EAS
  */
 require './@config/config.php';
 require './@config/db.config.php';
 require './libs/class.error.php';
 require './libs/class.config.php';
 require './libs/class.employee.php';
 
 $empid = $_GET["empid"];
 $emp = EAS_EMPLOYEE::ID($empid);
 
 if($empid != null) {
 	 $q1 = "DELETE FROM employees WHERE id='{$empid}'";
 	 $q2 = "DELETE FROM attendance WHERE EMP_ID='{$empid}'";
 	 
 	 if($sql->query($q1) && $sql->query($q2))
 	 {
 	 	echo "1";
 	 } else {
 	 	echo "0";
 	 }
 }
?>
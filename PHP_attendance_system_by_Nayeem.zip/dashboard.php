<?php
 /**
  * Dashboard for EAS App, Copyright (c) 2017
  *
  * @package EAS
  */
 session_start(); //session
 /**
  * get some libraries to include some features
  */
 require './@config/config.php';
 require './@config/db.config.php';
 require './libs/class.error.php';
 require './libs/class.config.php';
 /**
  * @check session if logged or not
  */
 if(!isset($_SESSION["Email"])) {
 	//not logged in
 	header("Location: ./index.php?login_=query");
 } else {
 	//logged in
?><!DOCTYPE html>
<html lang="en">
   <head>
      <title>Attendance System</title>
      <meta charset="utf-8">
      <!-- <meta name="viewport" content="initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no"> 
      <meta http-equiv="X-UA-Compatible" content="IE=edge"> -->
      <meta name="msapplication-tap-highlight" content="no">
      <meta name="theme-color" content="#607d8b">
      <link rel="STYLESHEET" href="./res/css/materialize.min.css"/>
      <link rel="STYLESHEET" href="./res/css/icons.css" />
      <link rel="STYLESHEET" href="./res/css/font-awesome.min.css" />
      <script src="./res/js/jquery.min.js"></script>
      <script src="./res/js/materialize.min.js"></script>
      <script src="./res/js/framework.js"></script>
      <style>
         a.brand-logo {
            font-size: 25px;
            margin-left: 15px;
         }
         .searchbar {
            margin-right: 10px;
            padding: 0px;
         }
         .searchbar input[type=search] {
            border-bottom: 2px solid white;
         }
         .searchbar input[type=search]:focus {
            border-bottom: 2px solid white;
         }
         table.responsive-table {
            margin-left: 10px;
            margin-right: 10px;
            margin-top: 10px;
            width:97.9%;
            border-radius: 2px;
            border: 1px solid #a6a6a6;
         }
         table.responsive-table th, td {
            padding: 15px 18px;
         }
         table.responsive-table td.option {
            color: #009688;
         }
         
         iframe {
         	position:absolute; left: 0; right: 0;
         	width: 100%;
         	height: 100%;
         	border: 0;
         	padding: 0;
         	margin: 0;
         }

         .about-cont {
            border-radius: 2px;
            background: white;
            margin: 20%;
            margin-top: 2%;
            border: 1px solid #a6a6a6;
            box-shadow: 0 8px 16px 0 rgba(0, 0, 0, 0.1);
         }
         .about-cont .header {
            padding: 10px;
            border-bottom: 1px solid #a6a6a6;
            font-weight: bolder;
            font-family: Aharoni;
         }
         .about-cont .body {
            padding: 10px;
            font-family: Arial;
            color: grey;
         }
      </style>
   </head>
   <body>
   <nav class="nav-extended header" style="background: #009688">
      <div class="nav-wrapper">
         <a href="#" class="brand-logo"><?php echo EAS_Config::getAppName(); ?></a>
         <a href="#" data-activates="mobile-demo" class="button-collapse"><i class="fa fa-bars"></i></a>
         <div class="right searchbar">
            <span class="fa fa-refresh" style="margin-right: 10px;" onclick="window.location.replace('');"> Refresh</span>&nbsp;|&nbsp; &nbsp;<span class="fa fa-sign-out" style="margin-right: 10px;" onclick="window.location.replace('logout.php?referer_=null&replace_=logout&__');"> Logout</span>
         </div>
      </div>
      <div class="nav-content">
         <ul class="tabs tabs-transparent">
            <li class="tab"><a class="active" href="#employees">Employees</a></li>
            <li class="tab"><a href="#add_employee">Add employee</a></li>
            <li class="tab"><a href="#attendance">Attendance</a></li>
            <li class="tab"><a href="#salaries">Salaries</a></li>
            <li class="tab"><a href="#departments">Departments</a></li>
            <li class="tab"><a href="#settings">Settings</a></li>
            <li class="tab"><a href="#about">About app</a></li>
         </ul>
      </div>
   </nav>

   <!-- Employees tab -->
   <div id="employees" class="col s12">
      <iframe cellspacing="0" src="./employees.php" frameborder="0"></iframe>
   </div>
   <!-- tab ends -->
   
   
   <!-- Add Employee tab -->
   <div id="add_employee" class="col s12">
      <iframe cellspacing="0" src="./add_employee.php" frameborder="0"></iframe>
   </div>
   <!-- tab ends -->


   <!-- attendance tab-->
   <div id="attendance" class="col s12">
   	<!-- Add attandance -->
      <iframe cellspacing="0" src="./attendance.php" frameborder="0"></iframe>
   </div>
   <!-- tab ends -->
   
   <!-- salaries tab -->
   <div id="salaries" class="col s12">
      <script>
        $("#salaries").load("salaries.php");
      </script>
   </div>
   <!-- tab ends -->
   
   <!-- departments tab -->
   <div id="departments" class="col s12">
      <iframe cellspacing="0" src="./departments.php" frameborder="0"></iframe>
   </div>
   <!-- tab ends -->
   
   <!-- settings tab -->
   <div id="settings" class="col s12">
      <iframe cellspacing="0" src="./settings.php" frameborder="0"></iframe>
   </div>
   <!-- tab ends -->
   
   
   <!-- about tab -->
   <div id="about" class="col s12">
      <div class="about-cont">
         <div class="header">About this app</div>
         <div class="body">
            This app "Employee Attendance System" helps you to manage the attendance list of your employees easily. The features of this app are the following:
            <br/>
            <ol>
               <li> Admin panel with secured login system</li>
               <li> Employee registration</li>
               <li> Employee editing & deleting</li>
               <li> Employee attendance caller</li>
               <li> Attendance caller activity after 9.00am to 6.00pm</li>
               <li> Employee salary management counting duty records</li>
               <li> Salary payment slip</li>
               <li> Setup departments for employees</li>
               <li> App controle panel</li>
               <li> App settings for setuping this app</li>
               <li> Encripted configuration file(hex)                                                                                                                           </li>
               <li> Activity, using only a mysql database</li>
               <li> Database phpMyAdmin accessable</li>
            </ol>
         </div>
      </div>
   </div>
   <!-- tab ends -->
   
   </body>
</html><?php
   }
?>
/**
 * Javascript document --
 * Copyright (c) 2016 by NAYEEM TANVIR
 */
$(function(){
    /*
     * a function for validating forms, employee registration
     */
    function validateRegForm() {
        var fname = document.forms["RegisterEmployee"]["fname"].value;


        return false;
    }
})();
/**
 * Javascript document --
 * Copyright (c) 2016 by NAYEEM TANVIR
 */
 var JQuery = $(document);
JQuery.ready(function(){
	var $window = $(window);
	var navbar = $(".header");
	var wrapper = $(".nav-wrapper");
	var content = $(".nav-content");
	var sidebar = $("#sidebar");
	var preScrollTop = 0;
	var autoHideNav = true;
	var animationDuration = "0.3s";
	
	
	/**
	 * @animation, for nav bar when hiding or appearing before the client
	 */
	navbar.css("transition", animationDuration);

	
	/**
	 * @scroll top, make the navbar fixed on top when body is scrolled about 61
	 * @scroll top, make the nav bar relative when scrolled less than 61
	 */
	$(window).scroll(function(){
	if($(window).scrollTop() > 40) {
		
		/**
		 * auto hide nav bar when scrolling bottom
		 * auto appear nav bar when scrolling top
		 */
		if(autoHideNav == true) {
			var scrolled = $window.scrollTop();
			var scrollDelta = $window.scrollTop() - preScrollTop;
			preScrollTop = scrolled;
			if(scrollDelta < 0) {
				/*alert("nav should be shown");*/
				wrapper.show();
			} else {
				if(scrollDelta > 0) {
					wrapper.hide();
				}
			}
		}
	
		navbar.css("position", "fixed");
	} 
	
	
});


}); //jquery ends